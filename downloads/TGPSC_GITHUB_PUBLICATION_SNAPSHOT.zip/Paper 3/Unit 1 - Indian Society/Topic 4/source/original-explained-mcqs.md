# 30 original explained practice MCQs
**Original practice questions; NOT authenticated TGPSC PYQs.**

## 1. Which constitutional provision directly prohibits begar and comparable forced labour?
A. Article 23
B. Article 356
C. Article 30
D. Article 19(1)(a)
**Answer: A.** Article 23 prohibits forced labour; Article 24 separately addresses child employment in factories, mines and hazardous employment.

## 2. What is the central feature distinguishing Vetti from merely low-paid work?
A. Payment by the day
B. Agricultural setting
C. Absence of meaningful freedom to refuse imposed service
D. Seasonal timing
**Answer: C.** Vetti refers to coerced service embedded in local social power; not all low wages meet the same test.

## 3. Which Telangana historical episode prominently challenged forced agrarian service?
A. Quit India movement of 1942 alone
B. The 1956 linguistic reorganisation alone
C. The 2014 state election alone
D. Telangana peasant mobilisation of 1946–51
**Answer: D.** The peasant struggle challenged forced service, landlord levies and tenancy coercion, while later legal reforms are distinct events.

## 4. Which statute provides a specific legal framework for abolishing bonded labour?
A. Companies Act, 2013
B. Bonded Labour System (Abolition) Act, 1976
C. Indian Forest Act, 1927
D. Official Languages Act, 1963
**Answer: B.** The Act abolishes bonded labour (section 4) and expressly names Vetti in the explanation to section 2(b). Other options do not provide that framework; the statutory mention does not establish facts of any individual case.

## 5. Why is rehabilitation needed after release from coercive labour?
A. Dependence and threats can reproduce coercion
B. Release cancels all poverty automatically
C. Workers must return to recruiters
D. Rehabilitation is only a police duty
**Answer: A.** Safe livelihoods, wages and housing are needed to make legal freedom sustainable.

## 6. Which regional practice is explicitly included in the 1988 Devadasis prohibition statute?
A. PESA
B. Panchayat Samiti
C. Jogini
D. Gram Sabha
**Answer: C.** The official Telangana-adapted text lists Jogini among labels covered by the definition.

## 7. What is the legal status of dedication under section 3 of the 1988 Act?
A. Unlawful and void even when consent is alleged
B. Valid with parental permission
C. Only prohibited in cities
D. Valid after adulthood
**Answer: A.** Section 3 rejects dedication regardless of purported consent and protects the woman’s legal status.

## 8. Which approach best protects a survivor of ritual dedication?
A. Confidential protection, legal action and sustained livelihood support
B. Punishment of the dedicated woman
C. A ceremony without follow-up
D. Public identification at a village meeting
**Answer: A.** Survivor autonomy and safety are the outcomes; public exposure can create further harm.

## 9. Why should Devadasi history not be treated as one uniform institution?
A. Only one region used the term
B. All participants had identical legal status
C. Historical roles varied by place and period
D. No historical performance tradition existed
**Answer: C.** A rigorous account distinguishes historical performance traditions from contemporary coercive dedication.

## 10. Which official document establishes the adaptation of the 1988 Act for Telangana?
A. The 1973 Six-Point Formula
B. The 2009 December statement
C. G.O.Ms.No.14 dated 28 April 2016
D. G.O.610 of 1985
**Answer: C.** The Telangana-adapted India Code text identifies the 2016 adaptation under the Reorganisation Act.

## 11. Which condition is most closely associated with prolonged excessive fluoride exposure?
A. Fluorosis
B. Malaria
C. Tuberculosis
D. Goitre from iodine deficiency
**Answer: A.** Fluorosis affects teeth and bones; laboratory water testing and exposure history are central.

## 12. Which Telangana district is a historically documented fluorosis case?
A. All districts uniformly
B. Nalgonda
C. Only Medchal
D. Only Hyderabad
**Answer: B.** Nalgonda district government documents groundwater fluoride and its monitoring centre; not every borewell is equally affected.

## 13. What was established in Nalgonda on 14 November 2013?
A. Hyderabad Metropolitan Development Authority
B. District Fluoride Monitoring Centre
C. National Green Tribunal
D. State Election Commission
**Answer: B.** The district government dates its coordination centre to 14 November 2013.

## 14. What does the DGHS NPPCF guidance identify as the desirable fluoride level?
A. 0.001 mg/L
B. 1.0 mg/L
C. 10 mg/L
D. 50 mg/L
**Answer: B.** DGHS describes 1.0 mg/L as desirable; distinguish it from the BIS permissible value under specified conditions.

## 15. What is the strongest evidence that a piped-water scheme reduces fluorosis exposure?
A. Repeated testing of water actually consumed
B. Budget allocation alone
C. Ribbon-cutting photographs
D. Number of pipes installed alone
**Answer: A.** Functional safe delivery, household use and clinical surveillance test real impact.

## 16. Which legislation addresses child marriage?
A. Right to Information Act, 2005
B. Prohibition of Child Marriage Act, 2006
C. Representation of the People Act, 1951
D. Banking Regulation Act, 1949
**Answer: B.** The PCMA provides prevention and legal remedies; distinguish voidable from automatically void marriages.

## 17. Which statement about child marriage is legally more accurate?
A. Always automatically valid
B. Always automatically void without exception
C. Generally voidable, with specified cases void
D. Not regulated by Indian law
**Answer: C.** The PCMA differentiates voidability and particular void circumstances.

## 18. Which metric best tests girls’ educational inclusion?
A. Sustained attendance, learning and safe access
B. Admission alone
C. Uniform distribution alone
D. School building count alone
**Answer: A.** Retention and meaningful access reveal burdens hidden by enrollment totals.

## 19. Under the Child and Adolescent Labour (Prohibition and Regulation) Act, 1986 as amended, which distinction is correct?
A. Children may work for any employer if the work occurs after school hours.
B. Every form of work by adolescents is prohibited, including non-hazardous work.
C. Children's employment is prohibited subject to narrow statutory exceptions; adolescents are prohibited from listed hazardous occupations and processes.
D. Family-enterprise work is exempt even when it is hazardous or interferes with schooling.
**Answer: C.** Section 3 states the child-employment prohibition and limited family/artist exceptions; section 3A prohibits adolescent employment in listed hazardous work. A wrongly generalises a narrow family/artist exception to any employer; B wrongly extends the adolescent prohibition to all work; D ignores the hazardous-work and school-time conditions. Source C181-1: India Code, Act 61 of 1986 as amended, sections 2, 3 and 3A. This describes statutory design, not proof of enforcement.

## 20. Which approach best prevents return to child labour after rescue?
A. Closing the case at first admission
B. Photographs of rescued children
C. A single raid
D. School reintegration with family livelihood support and follow-up
**Answer: D.** Rescue without educational and economic follow-through risks repeated exploitation.

## 21. What is a major risk in subcontracted labour supply chains?
A. Responsibility can be obscured across contractors
B. No worker can be recruited through agents
C. All subcontracting is illegal
D. All employers automatically keep complete records
**Answer: A.** Tracing recruitment, wage payment and the principal employer is necessary for accountability.

## 22. What is the correct analytical view of labour migration?
A. Mobility can be voluntary; exploitation arises from specific conditions
B. Every migrant is legally protected in practice
C. Every migrant is trafficked
D. Migration is a crime
**Answer: A.** Distinguish migration from coercive recruitment, wage theft and unsafe conditions.

## 23. Which statement correctly describes the central legal transition for inter-State migrant workers as of November 2026?
A. The 1979 Inter-State Migrant Workmen Act remains the sole operative central framework; the labour codes have not commenced.
B. The 2020 OSH Code protects only contractor-recruited migrants and categorically excludes self-migrated workers.
C. The 1979 Act is a historical framework replaced under the Occupational Safety, Health and Working Conditions Code, 2020, effective 21 November 2025; actual entitlements depend on statutory coverage and applicable rules.
D. Every migrant worker receives every statutory benefit automatically, regardless of the Code's definitions and coverage conditions.
**Answer: C.** The Ministry of Labour and Employment confirms 21 November 2025 commencement of the four codes. Section 143 of the OSH Code repeals the 1979 Act with savings, while the Code's inter-State migrant-worker provisions include defined categories of contractor-recruited and self-migrated workers. The applicable establishment threshold, Central or State rules, savings and facts of employment still matter. Sources: Ministry of Labour and Employment 30 December 2025 year-end review; Gazette G.S.R. 934(E), 30 December 2025 (a draft-rules notification recording the Code's commencement and repeal, not itself the final rules).

## 24. What is an important migrant-child education measure?
A. Portable school records and bridge learning
B. Exclusion until permanent residence
C. No admission during seasonal moves
D. Only employer-run examinations
**Answer: A.** Continuity between source and destination schools reduces repeated learning disruption.

## 25. Which region is strongly associated with the early-1990s mass anti-arrack literacy mobilisation?
A. Nellore in undivided Andhra Pradesh
B. Only Adilabad forests
C. Only Hyderabad Old City
D. Only Warangal city
**Answer: A.** The mass anti-arrack movement was prominently rooted in Nellore; northern Telangana had distinct earlier anti-liquor organising.

## 26. Why did women’s anti-arrack campaigns become a public-policy issue?
A. They opposed literacy
B. They excluded local government
C. They linked household harm and state excise decisions
D. They concerned only a single family
**Answer: C.** Collective mobilisation connected domestic burdens to licensing and state revenue policy.

## 27. A shop refuses service because of caste-based untouchability. Which constitutional Article directly abolishes the practice?
A. Article 17
B. Article 15(2)
C. Article 23
D. Article 24
**Answer: A.** Article 17 expressly abolishes untouchability and forbids its practice. B also protects against specified access discrimination, including shops, but does not itself contain the constitutional abolition clause; C prohibits trafficking, begar and forced labour; D addresses children's employment in factories, mines and hazardous work. Source C181-2: Constitution of India, Part III, Articles 15, 17, 23 and 24. The scenario is illustrative, not a finding in an actual case.

## 28. Which central law specifically defines atrocities against Scheduled Castes and Scheduled Tribes and provides for Special Courts and victim/witness safeguards?
A. Protection of Civil Rights Act, 1955
B. Scheduled Castes and Scheduled Tribes (Prevention of Atrocities) Act, 1989
C. Provisions of the Panchayats (Extension to the Scheduled Areas) Act, 1996
D. Bonded Labour System (Abolition) Act, 1976
**Answer: B.** The 1989 Act contains specified atrocity offences (section 3), Special Court provisions (section 14) and rights of victims and witnesses (section 15A). A addresses disabilities arising from untouchability but is not the named atrocities statute; C governs Panchayati Raj in Scheduled Areas; D abolishes bonded labour. Source C181-3: India Code, Act 33 of 1989, sections 3, 14 and 15A. Applicability to any alleged incident requires its facts and statutory elements.

## 29. In a Fifth Schedule Scheduled Area, which statute expressly requires the Gram Sabha to approve social and economic development plans before village-Panchayat implementation?
A. Provisions of the Panchayats (Extension to the Scheduled Areas) Act, 1996 (PESA)
B. Forest Rights Act, 2006, by itself for every Panchayat development plan
C. The general 73rd Constitutional Amendment alone, without Scheduled-Area modifications
D. Sixth Schedule autonomous-district provisions as a blanket rule for Fifth Schedule villages
**Answer: A.** PESA section 4(e)(i) provides the specified Gram Sabha approval function; section 2 links its Scheduled Areas to Article 244(1). B concerns forest-rights recognition and related functions, not this general PESA approval clause; C omits PESA's tailored extension of Part IX; D conflates distinct Fifth- and Sixth-Schedule arrangements. Source C181-4: India Code, Act 40 of 1996, sections 2–4. Actual local implementation and State rules require separate checking.

## 30. What is the strongest test of a self-help group’s empowerment impact?
A. Number of meetings alone
B. Loan totals alone
C. Photographs of beneficiaries
D. Members’ agency, earnings control and inclusive decision-making
**Answer: D.** Credit disbursement may help, but substantive agency and reduced vulnerability are more meaningful outcomes.

## Original practice MCQs with explanations (NOT official PYQs)

**Q1. Which Article defines State for Part III?**
A. Article 12
B. Article 32
C. Article 37
D. Article 51A

**Answer: A.** Article 12 is the threshold definition of State for Part III. Article 32 supplies a remedy, Article 37 concerns Directive Principles and Article 51A enumerates duties. Whether a public corporation is an “other authority” still requires the judicial instrumentality test.

**Q2. Which right is confined by text to citizens?**
A. Article 21
B. Article 20
C. Article 19
D. Article 14

**Answer: C.** Article 19(1) expressly secures its enumerated freedoms to citizens. Articles 14 and 21 use “person”, and Article 20 protects persons accused of offences. Do not assume that all rights have the same citizenship condition.

**Q3. Which is not a Fundamental Right today?**
A. Freedom of conscience
B. Right to property under Article 300A
C. Equality before law
D. Protection against exploitation

**Answer: B.** The Forty-fourth Amendment removed the original Fundamental Right to property; Article 300A now protects against deprivation except by authority of law. This is a constitutional legal right outside Part III, not an ordinary discretionary welfare benefit.

**Q4. Article 32 primarily concerns**
A. Local government
B. Constitutional remedies
C. Emergency powers
D. Budget allocation

**Answer: B.** Article 32 enables Supreme Court proceedings for enforcement of Fundamental Rights. Article 226 empowers High Courts to act for those rights and other legal purposes. The distinction is jurisdictional, not a claim that every grievance should be filed directly in the Supreme Court.

**Q5. Which High Court provision has broader writ reach?**
A. Article 226
B. Article 17
C. Article 39A
D. Article 44

**Answer: A.** Article 226 expressly permits High Court writs for enforcement of Fundamental Rights and for any other purpose. This broader wording can cover unlawful public action violating a statutory duty even when no independent Part III right is established.

**Q6. Article 37 describes DPSPs as**
A. Directly justiciable
B. Fundamental in governance but non-justiciable
C. Repealed
D. Applicable only to Union

**Answer: B.** Article 37 states that Directive Principles are not enforceable by courts, but fundamental in governance and duties of the State in making laws. A later statute implementing a directive may itself confer an enforceable entitlement.

**Q7. The privacy landmark of 2017 is**
A. Champakam
B. Puttaswamy
C. Indra Sawhney
D. Minerva Mills

**Answer: B.** The nine-judge decision in Justice K.S. Puttaswamy (Retd.) v Union of India (2017) recognised privacy as constitutionally protected. Privacy claims must still be analysed through legal authority, legitimate objectives and proportionality.

**Q8. Article 21A covers ages**
A. 0–6
B. 6–14
C. 14–18
D. All ages

**Answer: B.** Article 21A specifies free and compulsory education for children aged six to fourteen as provided by law. Article 45 separately concerns early childhood care and education for children below six; the two provisions should not be interchanged.

**Q9. Article 17 concerns**
A. Untouchability
B. Speech
C. Property
D. Education

**Answer: A.** Article 17 abolishes untouchability and forbids its practice in any form. The Protection of Civil Rights Act, 1955 and SC/ST (Prevention of Atrocities) Act, 1989 provide distinct statutory enforcement routes depending on the alleged conduct.

**Q10. The writ against unlawful detention is**
A. Mandamus
B. Quo warranto
C. Habeas corpus
D. Certiorari

**Answer: C.** Habeas corpus requires justification of detention or confinement. Mandamus commands performance of a public duty, certiorari corrects certain unlawful decisions and quo warranto tests legal title to a public office.

**Q11. The 42nd Amendment inserted**
A. Part IVA
B. Article 21A
C. Article 300A
D. Article 32

**Answer: A.** The Forty-second Amendment Act, 1976 inserted Part IVA and Article 51A. Article 21A and duty 51A(k) came through the Eighty-sixth Amendment, while Article 300A followed the Forty-fourth Amendment.

**Q12. The 86th Amendment added duty relating to**
A. Voting
B. Education opportunities for ages 6–14
C. Taxation
D. Military service

**Answer: B.** Article 51A(k) requires a parent or guardian to provide opportunities for education to a child or ward aged six to fourteen. It was added by the Eighty-sixth Amendment Act, 2002, alongside changes affecting education rights and directives.

**Q13. Which case stressed balance between Parts III and IV?**
A. Minerva Mills
B. Shreya Singhal
C. Olga Tellis
D. Vishaka

**Answer: A.** Minerva Mills v Union of India (1980) emphasised harmony and balance between Parts III and IV as constitutionally significant. It rejected a blanket expansion that would immunise laws implementing every DPSP from key rights review.

**Q14. Article 39A is about**
A. Free legal aid and equal justice
B. Forests
C. Village panchayats
D. International peace

**Answer: A.** Article 39A directs equal justice and free legal aid. Article 40 concerns village panchayats; Article 48A environmental protection; Article 51 international peace. Accurate article-to-subject mapping is a common exam differentiator.

**Q15. Which ruling struck down IT Act section 66A?**
A. Maneka Gandhi
B. Shreya Singhal
C. Puttaswamy
D. Kesavananda

**Answer: B.** Shreya Singhal v Union of India (2015) invalidated section 66A of the IT Act because of vague and overbroad speech restrictions. The judgment does not invalidate every law regulating threats or incitement.

**Q16. A privately operated hazardous workshop employs a 12-year-old child. Which constitutional provision most directly addresses this employment, even without proof of debt bondage?**
A. Article 24
B. Article 23(1)
C. Article 21A
D. Article 39(e)

**Answer: A.** Article 24 directly prohibits employment of children below fourteen in factories, mines and other hazardous employment. Article 23(1) concerns trafficking, begar and similar forced labour, which would require additional facts; Article 21A concerns education of ages six to fourteen; Article 39(e) is a Directive Principle addressing protection of workers and children. The Child and Adolescent Labour (Prohibition and Regulation) Act supplies additional statutory rules. This is an original practice scenario, not an official PYQ.

**Q17. A State forest department plans a lake-restoration programme while citizens volunteer to prevent littering. Which constitutional pairing is accurate?**
A. Article 51A(g) is the State's Directive Principle; Article 48A is the citizens' Fundamental Duty
B. Article 48A is a directly enforceable Fundamental Right; Article 51A(g) is a Directive Principle
C. Article 48A directs the State to protect the environment; Article 51A(g) places an environmental duty on citizens
D. Article 32 automatically orders every citizen to undertake a fixed number of lake-cleaning hours

**Answer: C.** Article 48A appears in Part IV and addresses the State; Article 51A(g) appears in Part IVA and addresses citizens. Neither text, standing alone, specifies a fixed number of hours or automatically creates the remedy asserted in D. A reverses the addressees, and B reverses the constitutional classification. Environmental rights or statutory duties may be enforceable through other legal routes; do not equate a Directive Principle with an independently executable decree.

**Q18. A privately operated restaurant open to the public refuses service to an Indian citizen solely because of caste. Which constitutional provision most directly addresses this specified access discrimination?**
A. Article 16(4), enabling certain public-employment reservations
B. Article 15(2)(a), covering access to public restaurants among other specified places
C. Article 15(1), which by its text prohibits only discrimination by the State
D. Article 29(2), dealing with admission to State-maintained or State-aided educational institutions

**Answer: B.** Article 15(2)(a) protects citizens against discrimination on listed grounds in access to public restaurants, including the stated private-operator setting. A concerns State-service reservation, not restaurant entry. C is the State-directed clause and is not the most direct provision on these facts. D addresses admission to specified educational institutions, not restaurants. The scenario assumes the refusal was solely on the prohibited ground; evidence and applicable statutory remedies require separate assessment.

**Q19. A licensing authority cancels a licence by citing only an internal circular, although the governing statute requires a hearing and the authority provides no reasons. Which response best reflects the rule of law?**
A. Treat every internal circular as automatically superior to the governing statute
B. Accept the cancellation because administrative discretion is never reviewable
C. Assume only criminal convictions, not administrative decisions, can be tested for legality
D. Check statutory authority, the required hearing, reasons and available review before treating the cancellation as valid

**Answer: D.** The stipulated statute requires a hearing; an internal circular cannot dispense with that statutory safeguard. The authority must identify lawful power and follow the applicable procedure, with reasons and review assessed under the governing legal framework. A wrongly elevates a circular over legislation; B invents immunity from review; C incorrectly confines legality review to criminal matters. This is a hypothetical administrative-law application, not a claim that every decision requires an identical hearing process.

**Q20. A recruitment notice says Article 16(4) itself guarantees an individual a reserved government post, even without an operative reservation policy. Which is the most accurate correction?**
A. Article 16(4) enables the State to provide reservation for a backward class inadequately represented in State services; it does not by itself award a particular applicant a post
B. Article 16(4) directly fixes a universal reservation percentage for every class and every post
C. Article 16(4A) automatically reserves every promotion for all citizens, irrespective of category
D. Article 16(3) lets any State department impose residence requirements by an internal circular without parliamentary law

**Answer: A.** Article 16(4) is enabling and addresses reservation of appointments or posts for inadequately represented backward classes; implementation and the applicable legal conditions must be checked separately. B invents a universal constitutional percentage. C misstates Article 16(4A), which concerns enabling promotion reservation for SCs/STs under specified conditions. D ignores Article 16(3)'s allocation of the residence-requirement lawmaking power to Parliament. A notice cannot itself convert enabling constitutional language into an automatic individual appointment.

**Q21. A government welfare portal rejects a visually impaired applicant because its only identity test requires blinking. Which is the strongest constitutional-administrative response?**
A. Reject permanently because software applies equally to all
B. Provide an accessible alternative and human review under applicable law
C. Abolish identity checks for everyone
D. Treat the dispute solely as a private contract

**Answer: B.** In *Pragya Prasun & Ors. v Union of India & Ors.*, decided on 30 April 2025 (2025 INSC 599), the Supreme Court addressed inaccessible digital KYC/e-KYC/video KYC affecting persons with disabilities and required accessible verification alternatives. The welfare-portal example in this question is an **application of that accessibility principle**, not the precise factual dispute or an automatic holding about every government portal. A lawful identity check may continue, but accessible alternatives and appropriate human assistance should be considered under the applicable disability and scheme rules.

**Q22. A State announces a reservation policy in a press conference, but no applicable law or operative order is shown. What should an administrator do?**
A. Apply the announcement immediately
B. Ignore all affirmative action permanently
C. Verify statutory authority, commencement, rules and judicial orders before applying it
D. Assume the Supreme Court has approved the exact percentage

**Answer: C.** Political intent, legislation, Gazette publication, commencement and judicial validity are distinct stages. In Telangana, Act 15 of 2025 is an enacted SC sub-classification example, whereas other proposed quota changes have faced litigation. Rule of law requires the legally applicable instrument for the specific recruitment or admission.

**Q23. A peaceful group criticises government policy near a hospital. Which measure best reconciles Article 19 and public safety?**
A. Permanent blanket ban on all critical gatherings
B. Permit all obstruction irrespective of ambulances
C. Impose evidence-based, narrowly tailored traffic and safety conditions under valid law
D. Require protesters to praise government

**Answer: C.** Speech and peaceful assembly are protected but subject to their own constitutional restriction clauses. A carefully reasoned route or timing condition may protect emergency access without extinguishing dissent. Blanket suppression of criticism or unlimited obstruction fails to analyse competing constitutional interests.

**Q24. A private brick-kiln operator prevents migrant workers from leaving until an alleged debt is repaid. Which provision is most directly relevant?**
A. Article 23
B. Article 44
C. Article 50
D. Article 300A

**Answer: A.** Article 23 prohibits trafficking, begar and similar forced labour and is not confined to State employers. Inspectors should investigate coercion, wage records and freedom to leave under the applicable bonded-labour and criminal-law framework. Article 44 concerns a uniform civil code and Article 300A concerns property.

**Q25. A citizen seeks a writ demanding a particular amount of free public assistance solely because Article 41 mentions public assistance. Which statement is most accurate?**
A. Article 41 alone guarantees that precise amount as an immediately enforceable right
B. Article 37 makes every welfare law unenforceable
C. Article 41 is a non-justiciable directive; an implementing statute may separately create enforceable claims
D. Article 41 is a Fundamental Duty

**Answer: C.** Article 37 expressly describes Directive Principles as non-enforceable by courts but fundamental to governance. A legislature can transform a policy objective into a statutory entitlement with eligibility and remedy. Students must identify the relevant statute rather than treat a directive as either worthless or an unlimited judicial order.


# Original practice MCQs with explanations — NOT official PYQs

**Provenance:** All 30 questions below are newly written for this draft. They are not represented as questions from a TGPSC, UPSC or other official examination.

### Q1. Which institution can directly remove the Union Council of Ministers through a vote of no confidence?
A. Rajya Sabha  
B. Lok Sabha  
C. Joint sitting of both Houses  
D. President acting alone  
**Answer: B.** Article 75(3) makes the Union Council collectively responsible to the Lok Sabha, so B is correct. A is wrong because Rajya Sabha can question the ministry but cannot withdraw the confidence constitutionally required from Lok Sabha. C is wrong because an Article 108 joint sitting resolves specified legislative deadlocks, not ministerial confidence. D is wrong because the President is the constitutional head, not an independently voting house empowered to remove a ministry through a no-confidence motion. [S14]

### Q2. Which of the following is *not* included in the President's electoral college?
A. Elected Lok Sabha members  
B. Elected Rajya Sabha members  
C. Elected members of Telangana Legislative Assembly  
D. Elected members of Telangana Legislative Council  
**Answer: D.** Article 54 includes elected members of both Houses of Parliament (A and B) and elected members of state Legislative Assemblies, including Telangana (C). It does not include elected state Legislative Council members (D, the correct exclusion). Nominated MPs are also outside the Article 54 college; do not confuse this election with the Vice-President election under Article 66. [S14]

### Q3. A President returns the Council of Ministers' advice for reconsideration under Article 74. The Council reiterates it. The President must:
A. Call a national referendum  
B. Refer it automatically to the Supreme Court  
C. Act in accordance with the reconsidered advice  
D. Dismiss the Council  
**Answer: C.** Under the proviso to Article 74(1), the President may seek reconsideration, but must act on the advice tendered after reconsideration; C is correct. A is wrong because Article 74 creates no referendum mechanism. B is wrong because no automatic Supreme Court reference is prescribed for reiterated advice. D is wrong because disagreement with reiterated advice does not itself authorise dismissal of the Council. This is distinct from exceptional situations involving loss of Lok Sabha confidence. [S14]

### Q4. A person appointed Union minister without membership of either House must normally obtain membership within:
A. Three months  
B. Six months  
C. One year  
D. The full Lok Sabha term  
**Answer: B.** Article 75(5) makes a Union minister cease to hold office after six consecutive months without membership of either House, so B is correct. A and C invent three-month and one-year periods not found in that clause; D incorrectly ties the deadline to the full Lok Sabha term, even though Rajya Sabha membership also qualifies. Article 164(4) contains the analogous state-legislature rule. [S14]

### Q5. With 119 members in the Telangana Assembly, what is the maximum size of its Council of Ministers including the Chief Minister under Article 164(1A)?
A. 12  
B. 17  
C. 18  
D. 20  
**Answer: B.** Fifteen percent of 119 is 17.85; the ministry cannot exceed the cap, so at most 17 ministers. The constitutional minimum of 12 does not change that maximum.

### Q6. Which statement best distinguishes a Money Bill from a financial bill that is not a Money Bill?
A. Every bill involving public money is a Money Bill.  
B. A Money Bill must contain only Article 110 matters; certain financial bills also include other substantive provisions.  
C. Rajya Sabha has the same veto over every Money Bill as over an ordinary bill.  
D. A Money Bill may originate in Rajya Sabha.  
**Answer: B.** Article 110 uses the restrictive 'only' test. Financial bills under Article 117 can have different procedural requirements and upper-house powers.

### Q7. Rajya Sabha must return a Union Money Bill with any recommendations within:
A. Seven days  
B. Fourteen days  
C. One month  
D. Three months  
**Answer: B.** Under Article 109, Rajya Sabha has fourteen days; Lok Sabha may accept or reject its recommendations.

### Q8. A joint sitting under Article 108 is *not* available for:
A. Qualifying deadlock on an ordinary bill  
B. Qualifying disagreement over an ordinary bill's amendments  
C. Constitutional amendment bill under Article 368  
D. A bill pending beyond the specified deadlock period  
**Answer: C.** Article 368 requires separate special majorities in each House; Money Bills also have no joint sitting.

### Q9. Which is a special Rajya Sabha power under the Constitution?
A. Passing no-confidence against Union ministry  
B. Voting demands for grants  
C. Authorising Parliament to legislate on State List matters in national interest under Article 249  
D. Dissolving Lok Sabha  
**Answer: C.** Article 249 provides a special resolution route; Articles 312 and 249 are distinctive federal functions of Rajya Sabha.

### Q10. Which description of the President's ordinance power is most accurate?
A. Ordinances may amend the Constitution without Parliament.  
B. Ordinances are valid indefinitely if re-promulgated.  
C. Article 123 permits temporary lawmaking under specified session and necessity conditions, subject to parliamentary control.  
D. An ordinance is a personal decree independent of the Cabinet.  
**Answer: C.** Ordinances have temporary statutory force but cannot bypass legislative competence, constitutional rights or reassembly limits.

### Q11. The constitutional provision making the state Council of Ministers collectively responsible to the Legislative Assembly is:
A. Article 164(2)  
B. Article 171  
C. Article 200  
D. Article 312  
**Answer: A.** Even in bicameral Telangana, the Council is responsible to the elected Assembly, not the Legislative Council.

### Q12. Under Article 169, creation or abolition of a State Legislative Council requires:
A. Governor's unilateral order  
B. Assembly special resolution followed by a law of Parliament  
C. Simple Council majority alone  
D. Presidential ordinance alone  
**Answer: B.** The Assembly resolution has prescribed majorities; Parliament then acts by law. A state resolution does not itself abolish the Council.

### Q13. Telangana has 119 Assembly seats and a 40-seat Legislative Council. Which constitutional explanation resolves the apparent one-third ceiling problem?
A. The one-third limit applies only to Union Territories.  
B. Article 171(1) also requires a minimum of forty Council members, so the general ceiling must be read with its proviso.  
C. Council seats are excluded from every constitutional numerical limit.  
D. The Governor may enlarge the Council to any size by executive order.  
**Answer: B.** The general ceiling of one-third of 119 is about 39.67, but Article 171(1)'s proviso requires at least forty Council members. Telangana officially reports a 40-seat Council. Article 164(1A)'s ministerial ceiling is separate. [S2][S3]

### Q14. For an ordinary bill initially passed by a state Assembly, Article 197 permits the Assembly to prevail after prescribed Council delays of:
A. Six months and six months  
B. Three months at first stage and one month at second stage  
C. Fourteen days at each stage  
D. One year at each stage  
**Answer: B.** This is the specified ordinary-bill mechanism. A state legislature has no joint sitting to resolve the disagreement.

### Q15. A state Money Bill is governed primarily by which article's definition?
A. Article 110  
B. Article 171  
C. Article 199  
D. Article 249  
**Answer: C.** Article 199 defines state Money Bills; Article 110 is the Union definition. Both must be read with their respective procedural provisions.

### Q16. Which is the correct conclusion of the Supreme Court's 2025 Presidential Reference concerning state-bill assent?
A. Courts must grant deemed assent after three months.  
B. Governors may block any bill forever without scrutiny.  
C. Courts cannot set universal assent deadlines or deem assent, but prolonged unexplained gubernatorial inaction may receive limited review.  
D. The Governor must assent to every bill immediately.  
**Answer: C.** Presidential Reference No. 1 of 2025 (2025 INSC 1333) distinguishes impermissible judicial substitution from limited review of indefinite obstruction.

### Q17. Which 2024 judgment held that bribery connected with a legislative vote is not immune under Articles 105/194?
A. *S.R. Bommai*  
B. *Sita Soren v Union of India*  
C. *Kihoto Hollohan*  
D. *Kesavananda Bharati*  
**Answer: B.** The seven-judge Bench in *Sita Soren* (2024 INSC 161) rejected immunity for bribery while preserving constitutional protection for genuine speech and votes.

### Q18. An MLA criticises a minister during Assembly debate. The starting constitutional protection is:
A. Article 194  
B. Article 32 alone  
C. Article 356  
D. Article 360  
**Answer: A.** Article 194 governs state legislative freedom of speech and related immunity, subject to constitutional and House rules.

### Q19. Which is most consistent with the Tenth Schedule?
A. Every disagreement with party leadership is automatically disqualification.  
B. Any one MLA can create a legally protected merger.  
C. Specified acts such as voluntarily giving up party membership or voting against a direction can trigger disqualification, subject to rules and exceptions.  
D. Speaker decisions are wholly immune from judicial review.  
**Answer: C.** The Tenth Schedule has defined triggers, exceptions and procedural questions; *Kihoto Hollohan* recognises judicial review.

### Q20. Which of the following is *not* a correct use of the phrase 'collective responsibility'?
A. The ministry must retain confidence of the elected lower house.  
B. Ministers ordinarily defend adopted cabinet decisions publicly.  
C. Every individual minister may be removed by a separate Lok Sabha no-confidence motion under Rule 198.  
D. Loss of confidence of the ministry can require resignation.  
**Answer: C.** The no-confidence motion is against the Council as a body, not a device to constitutionally dismiss one minister.

### Q21. Which parliamentary committee most directly examines CAG reports on appropriation and expenditure?
A. Public Accounts Committee  
B. Rules Committee  
C. Ethics Committee  
D. Committee on Petitions  
**Answer: A.** PAC's focus is accounts, legality and financial accountability; Estimates Committee and Committee on Public Undertakings have different roles.

### Q22. What is the best description of Zero Hour?
A. It is expressly created by Article 110.  
B. It is a parliamentary practice after Question Hour for raising matters, not a constitutional article by that name.  
C. It is a substitute for all written questions.  
D. It is the same as the annual budget vote.  
**Answer: B.** Lok Sabha's official FAQ distinguishes the parliamentary convention of Zero Hour from the rule-governed Question Hour.

### Q23. Which statement accurately reports PRS's 2025 state-legislature review?
A. Telangana's Council is constitutionally required to sit for eleven days.  
B. All state Councils sat exactly eleven days.  
C. Telangana's Council sat for eleven days in 2025 according to PRS's compilation; this is descriptive evidence, not a legal threshold.  
D. Telangana had no Council in 2025.  
**Answer: C.** PRS reported eleven Telangana Council sitting days; institutional quality needs additional indicators beyond day count.

### Q24. Which part of Parliament controls voting on demands for Union grants?
A. Rajya Sabha only  
B. Lok Sabha only  
C. Both Houses by joint sitting  
D. Supreme Court  
**Answer: B.** Article 113 places demands for grants before Lok Sabha; Rajya Sabha can discuss but does not vote them.

### Q25. Which statement about the Governor's office is constitutionally accurate?
A. Governor is directly elected by Telangana voters.  
B. Governor may ordinarily replace the CM's policy advice with personal preferences.  
C. Governor is appointed by the President and normally acts on state ministerial advice, subject to constitutionally specified discretion.  
D. Governor can personally vote on every Assembly bill.  
**Answer: C.** Articles 155 and 163 govern appointment and advice. Exceptional discretion must be grounded in the Constitution and controlling case law.

### Q26. Which interval does Article 85(1) restrict when Parliament is summoned?
A. The interval between the last sitting of one session and the first sitting of the next session must not reach six months.
B. The interval between successive general elections must never exceed six months.
C. Parliament must conduct at least six months of sittings every calendar year.
D. Every two consecutive daily sittings must be less than six months apart.
**Answer: A.** Article 85(1) measures the gap from the last sitting of one session to the first sitting of the next. B confuses session summoning with elections; C invents a minimum duration of sittings; D incorrectly treats every pair of daily sittings as the constitutional reference points. [S13]

### Q27. Until Parliament provides otherwise by law, what is the constitutional quorum for a meeting of either House under Article 100(3)?
A. A majority of the House's total membership.
B. One-third of the total membership.
C. Two-thirds of members present and voting.
D. One-tenth of the total membership.
**Answer: D.** Article 100(3) specifies one-tenth of the total membership, subject to Parliament legislating otherwise. A and B invent different fractions; C confuses a special voting threshold with the quorum needed to conduct a sitting. Article 100(4) addresses absence of quorum. [S13]

### Q28. A non-Money Bill returned by the President under Article 111 is passed again by both Houses. What follows?
A. The President may return the same Bill repeatedly without limit.
B. The President must call a joint sitting regardless of whether the Houses agree.
C. The President shall not withhold assent after the Bill is passed again with or without amendment.
D. The President may require a referendum before assent.
**Answer: C.** Article 111 expressly bars withholding assent after the returned non-Money Bill is reconsidered and passed again. A invents a recurring return power; B confuses reconsideration with the separately conditioned Article 108 joint-sitting process; D invents a referendum requirement. Money Bills cannot be returned under this proviso. [S13]

### Q29. Under Article 123(1), which parliamentary-session situation can permit a presidential ordinance, assuming the immediate-action condition is satisfied?
A. Both Houses are in session and the Cabinet asks for an ordinance.
B. One House is not in session, even though the other House is in session.
C. Both Houses are in session but the ordinary legislative process is inconvenient.
D. Both Houses have passed a Bill and are awaiting the President's assent.
**Answer: B.** Article 123 excludes promulgation when both Houses are in session; one House being out of session can satisfy the session condition, but necessity and other constitutional limits remain. A and C fail the session restriction; D concerns assent to legislation, not an ordinance gateway. [S13]

### Q30. Which State Bill must the Governor reserve for the President under the second proviso to Article 200?
A. Every Bill dealing with a matter on the Concurrent List.
B. Every Bill affecting the remuneration of State ministers.
C. Every Bill passed by a Legislative Council.
D. A Bill that, in the Governor's opinion, would so derogate from High Court powers as to endanger its constitutional position.
**Answer: D.** The second proviso to Article 200 mandates reservation in the specified High Court-protection situation. A and B incorrectly turn subject matter into automatic reservation; C invents a rule about the originating House and ignores the Assembly-centred legislative procedure. This is distinct from discretionary reservation questions addressed in the 2025 Presidential Reference. [S13]


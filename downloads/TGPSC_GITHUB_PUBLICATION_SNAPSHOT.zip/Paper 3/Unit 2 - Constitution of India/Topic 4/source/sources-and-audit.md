# Authoritative Sources, Evidence Register and Internal Audit

**Research cut-off: 23 October 2026. Academic status: expanded draft; NOT academically approved.** Codes in detailed notes refer to the sources below. Source links are provided to support independent checking; references are to laws, provisions and judgments, not student-facing PDF page numbers. A source being listed does not mean every current legal development has received independent expert review.

| Code | Authority / source | URL | Claim checked / qualification |
|---|---|---|---|
| S1 | TGPSC Notification 02/2024, Annexure II, Paper III, II, item 4; publicly reproduced syllabus | https://websitenew.tgpsc.gov.in/preview/RElSRUNUUkVDUlVJVE1FTlROT1RJL05PVElGSUNBVElPTl9OT18wMi0yMDI0X0dyb3VwLUlfU2VydmljZXMgKDEpMjAyNDAyMjAxNDA3MzcucGRmr95v17a0y2d8i13v ; https://prepshark.in/tgpsc/group-1/syllabus | Exact wording checked against prior official-PDF checkpoint and line-for-line public reproduction. Official PDF returned HTTP 403 on this run. |
| S2 | Legislative Department, Constitution of India | https://lddashboard.legislative.gov.in/sites/default/files/coi/COI_2024.pdf | Articles 13, 32, 39A, 50, 124–147, 214–237, 323A–323B, 368. Portal timed out this run; stable constitutional provisions checked against official judicial explanations. |
| S3 | High Court for the State of Telangana, official portal | https://tshc.gov.in/hcts/ | Telangana court identity, court services, notifications and institutional context. |
| S4 | Supreme Court of India, Jurisdiction | https://www.sci.gov.in/jurisdiction/ | Article 32, 131, 136, 143; original, appellate and advisory powers; review/curative practice. |
| S5 | India Code, Administrative Tribunals Act, 1985 | https://upload.indiacode.nic.in/showfile?actid=AC_CEN_26_36_000010_198513_1517807325572&filename=a1985-13.pdf&type=actfile | CAT and State tribunal subject-matter distinctions, Sections 14 and 15. |
| S6 | Department of Justice, subordinate judiciary recruitment / parliamentary answer | https://dashboard.doj.gov.in/vacancy/ ; https://www.doj.gov.in/static/uploads/2025/09/04d247ddf5a1a6df49e2e61b32b58f15.pdf | Articles 233–235 responsibilities; historical 2014/2024 sanctioned-strength figures; NOT a live 2026 count. |
| S7 | Supreme Court, *L. Chandra Kumar v Union of India*, (1997) 3 SCC 261; discussion in official subsequent judgment | https://api.sci.gov.in/jonew/judis/43863.pdf | Basic-structure judicial review, tribunals as first instance and High Court supervision. Exact 1997 primary judgment not downloaded in this run; holding cross-checked in later Supreme Court judgment. |
| S8 | Supreme Court, *Rojer Mathew v South Indian Bank Ltd*, 13 November 2019 | https://api.sci.gov.in/supremecourt/2017/9680/9680_2017_1_1501_18247_Judgement_13-Nov-2019.pdf | Tribunal independence and institutional safeguards; avoid claiming all 2026 tribunal rules have been audited. |
| S9 | Supreme Court, NJAC judgment, 2015; related basic-structure discussion | https://api.sci.gov.in/jonew/judis/43070.pdf | NJAC invalidation, appointment independence, basic structure; references to *Kesavananda Bharati* and other landmark judgments. |
| S10 | Telangana State Legal Services Authority, introduction and Permanent Lok Adalat | https://telangana.nalsa.gov.in/introduction/ ; https://telangana.nalsa.gov.in/permanent-lok-adalat-for-public-utility-services/ | DLSAs across 33 districts, ordinary/PLA differences, locations and services. |
| S11 | Supreme Court press releases dated 5 May 2025 and assets page | https://www.sci.gov.in/press-release-dated-may-5-2025-2/ ; https://www.sci.gov.in/assets-of-judges/ | Appointments-process publication and Supreme Court judges' asset declaration policy; dated not generic all-courts claim. |
| S12 | India Code, National Green Tribunal Act 2010; Armed Forces Tribunal portal | https://www.indiacode.nic.in/ ; https://www.aft.gov.in/ | Tribunal-specific enabling laws and jurisdiction; no assumption that every tribunal shares CAT's rules. |
| S13 | Department of Justice, eCourts Phase III dashboard and 2026 official response | https://dashboard.doj.gov.in/ecourts-projects-phaseIII/ ; https://www.doj.gov.in/static/uploads/2026/04/aa21cd29d4b4a580d660c8c472e24ecd.pdf | Approved 2023–2027 programme outlay Rs 7,210 crore; allocation is distinct from expenditure. |
| S14 | e-Committee, Supreme Court, eCourts services portal | https://ecommitteesci.gov.in/service/ecourts-portal/ | NJDG, e-filing, e-pay, case status and virtual-court services; live pendency not asserted. |
| S15 | India Code, Legal Services Authorities Act, 1987 | https://www.indiacode.nic.in/handle/123456789/12883?view_type=browse | Sections 12–13 eligibility, Chapter VI Lok Adalats and Chapter VI-A Permanent Lok Adalats. |
| S16 | India Code, Bharatiya Nagarik Suraksha Sanhita, 2023 | https://www.indiacode.nic.in/indiacode/handle/123456789/20099?view_type=browse | Commencement 1 July 2024, criminal-court provisions; transitional caveat. |

## Internal doctrinal checks

1. Articles 32 and 226 are **not** interchangeable: Article 226 is wider in enforceable legal rights.
2. Article 227 supervision is not a general second appeal; Article 235 is separate administrative control over subordinate courts.
3. Article 136 special leave is discretionary; Article 143 advisory jurisdiction is distinct from appellate judgment.
4. *L. Chandra Kumar* does not abolish tribunals; constitutional review remains.
5. A tribunal's jurisdiction depends on its own enabling law, not just the general idea of specialisation.
6. NJAC was struck down in 2015; the collegium system remains controversial, not constitutionally infallible.
7. A judicial in-house inquiry is not the Article 124(4) constitutional removal process.
8. Ordinary Lok Adalats settle; Permanent Lok Adalats have limited merits adjudication after conciliation failure.
9. BNSS commencement and eCourts allocation are dated; no live 2026 caseload figure was invented.
10. All MCQs and mains questions are **original practice**, with **zero verified official PYQs**.

## Outstanding full academic-audit tasks

- Obtain the official TGPSC Notification 02/2024 PDF again from an accessible Commission endpoint and independently confirm punctuation and exact scope against the reproduced line.
- Check each doctrinal proposition against the full authoritative constitutional text, current amendments and the full judgments, including 2026 developments not incorporated here.
- Recheck current tribunal legislation and appointment rules, current Telangana High Court procedures, and the applicability of new criminal codes to transitional cases.
- Subject every MCQ to an independent distractor-ambiguity audit and each mains answer to a legal subject-matter review.
- Audit print accessibility, diagram legibility, link correctness, Unicode rendering and all PDF pages; visual render inspection is necessary but not academic approval.
- Recover byte access to the original 19-topic master and Topic 5 archive before claiming a complete cumulative archive.

**Status:** expanded draft, **academically approved = 0**, **official verified PYQs = 0**.

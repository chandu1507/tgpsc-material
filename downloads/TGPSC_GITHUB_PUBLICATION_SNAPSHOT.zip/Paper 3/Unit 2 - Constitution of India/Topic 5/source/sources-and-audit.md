# Authoritative source register and academic-audit status

**Research cutoff:** 23 October 2026. Sources are listed by document/institution and URL; no student-facing PDF page numbers are supplied. A source appearing here is not a claim that every assertion has received an independent academic audit.

| ID | Primary / institutional source | Used for | URL |
|---|---|---|---|
| S01 | TGPSC Notification 02/2024, Annexure-II (wording cross-checked against published reproduction; official PDF access not completed) | Exact syllabus line | https://prepshark.in/tgpsc/group-1/syllabus |
| S02 | Legislative Department, Constitution of India collection | Constitutional Articles and schedules | https://legislative.gov.in/constitution-of-india-archive |
| S03 | Ministry of Panchayati Raj, constitutional provisions | 73rd Amendment, Part IX and Eleventh Schedule | https://panchayat.gov.in/en/constitutional-provision/ |
| S04 | Ministry of Panchayati Raj, mapping of 29 subjects | Eleventh Schedule | https://panchayat.gov.in/en/document/mapping-of-29-subjects-under-eleventh-schedule-of-the-constitution-sdgs-and-lsdg-themes/ |
| S05 | GST Council, constitutional design | Article 279A membership and functions | https://www.gstcouncil.gov.in/gst-council-0 |
| S06 | GST Council, *Mohit Minerals* case note | Cooperative federalism and persuasive recommendations | https://www.gstcouncil.gov.in/sites/default/files/gst-knowledge/GST-and-Co-operative-Federalism.pdf |
| S07 | Finance Commission of India | Article 280 and Union–State/local-body finance | https://fincomindia.nic.in/ |
| S08 | Sixteenth Finance Commission, Volume I | Local-body grants and state perspectives (recommendations, not disbursements) | https://fincomindia.nic.in/asset/doc/commission-reports/16th-FC/reports/Vol1-Main-Report.pdf |
| S09 | India Code, Inter-State River Water Disputes Act, 1956 | Tribunal framework and adjudication | https://www.indiacode.nic.in/indiacode/handle/123456789/1664?view_type=browse |
| S10 | India Code, Andhra Pradesh Reorganisation Act, 2014 | Sections 84–85 and special water framework | https://upload.indiacode.nic.in/showfile?actid=AC_CEN_5_5_00058_201406_1517807327989&filename=201406.pdf&type=actfile |
| S11 | Krishna River Management Board, official FAQ | Constitution, board functions, Apex Council | https://www.krmb.gov.in/krmb/feedback |
| S12 | Krishna River Management Board, functioning norms | Section 85(8) operating responsibilities | https://krmb.gov.in/krmb/RTI?link=functioningNorms |
| S13 | Krishna River Management Board, annual report | July 2021 jurisdiction notification and operations | https://krmb.gov.in/uploadedFiles/annualReport/AR2021-22English-FINAL.pdf |
| S14 | Telangana Socio Economic Outlook 2024 | Panchayat/municipality structure and historical counts | https://des.telangana.gov.in/publications/Socio%20Economic%20Outlook-2024.pdf |
| S15 | Telangana district administration, Hanumakonda Panchayat Office | Telangana Panchayat Raj Act, 2018 and local service examples | https://hanumakonda.telangana.gov.in/district-panchayat-raj-office/ |
| S16 | Telangana BuildNow government acts register | Telangana Municipalities Act, 2019 | https://buildnow.telangana.gov.in/go-and-act/ |
| S17 | Telangana Sangareddy district Panchayat Office | Local governance duties and finance sources | https://sangareddy.telangana.gov.in/district-panchayath-office/ |
| S18 | Supreme Court of India, Presidential Reference 2025 | Governors and assent: avoid outdated blanket claims | https://www.api.sci.gov.in/supremecourt/2025/39157/39157_2025_1_1501_66169_Judgement_20-Nov-2025.pdf |
| S19 | TGPSC, Paper III question-paper pattern | Mains answers around 200 words | https://websitenew.tspsc.gov.in/preview/UFJFU1NOT1RFL0dyb3VwIDEtIE1haW4gRXhhbS1RdWVzdGlvbiBQYXBlciBQYXR0ZXJuMjAyMzAxMTgyMDQ4NTIucGRmr95v17a0y2d8i13v |

## Internal verification notes

- Checked the **Article 262 / 1956 Act / tribunal** distinction against India Code; Article 262 does not directly allocate water.
- Checked **section 84 Apex Council versus section 85 boards** against KRMB and the Reorganisation Act.
- Checked **29 Eleventh Schedule subjects versus 18 Twelfth Schedule subjects** and the nonautomatic character of devolution.
- Checked **2019 Telangana Municipalities Act** and **2018 Telangana Panchayat Raj Act** against government sources.
- Avoided presenting **2024 municipal-body counts as current**.
- Distinguished **GST Council recommendations** from binding legislation and **Finance Commission recommendations** from actual transfers.
- Marked all questions as **original practice**, not verified official PYQs.

## Audit status

**Academically approved: NO.** Independent full source-to-claim review, line-by-line legal review, numerical verification and a second subject-expert reading remain pending. The official Notification 02/2024 PDF was not freshly retrieved in this run; the syllabus wording is cross-checked with an attributed reproduction. There is no claim of an official verified PYQ.

## 27 October 2026 — bounded primary-source correspondence (Cycle 31)

- Ministry of External Affairs, official Constitution Part IXA extract, https://www.mea.gov.in/Images/pdf1/Part9.pdf — Article 243ZE Metropolitan Planning Committee: draft metropolitan development plan, municipal and panchayat plans, shared infrastructure and environmental conservation. Does not establish whether Hyderabad's current institutions fully comply.
- India Code, Inter-State River Water Disputes Act, 1956, official statutory PDF, https://www.indiacode.nic.in/bitstream/123456789/1664/3/A1956-33.pdf — Sections 6 and 11 checked for Gazette publication/binding effect and statutory jurisdictional bar. This check does not establish every possible appellate route.
- Ministry of Jal Shakti, official annual report, https://www.jalshakti-dowr.gov.in/static/uploads/2024/05/2023041116.pdf — describes KRMB/GRMB constitution and the 2014 Reorganisation Act; historical report is not proof of 2026 operating status.
- Two mains expansions are author-side source correspondences, not independent review. R1, all 25 MCQ keys/distractors, remaining mains claims, R2, R7 and R8 remain **not passed**.

## 30 October 2026 — Cycle 116 direct constitutional-text correspondence

- Directly viewed the Legislative Department's *Constitution of India*, English–Kannada official edition, as on 11 November 2025: https://www.legislative.gov.in/static/uploads/2025/07/359f70a69695affb9d72f8393102bd2e.pdf. Article 243ZD(2)(b), PDF page 322, requires **at least four-fifths** elected DPC members; Article 243ZE(2)(b), PDF page 324, requires **at least two-thirds** elected MPC members. Their different membership pools are retained in the worked examples.
- Article 243Y(1), PDF page 318, refers to the State Finance Commission constituted under Article 243I for municipal review. Article 243K(2), PDF page 302, protects the State Election Commissioner from removal except in like manner and on like grounds as a High Court judge. Article 243ZE(3), PDF page 324, enumerates the MPC's planning inputs.
- Five **new original practice** MCQs Q26–Q30 have author-side correspondence for their five keys and all fifteen distractors. The first 25 MCQs and all six mains remain **not independently claim-audited**. No official PYQ or authenticated current Telangana DPC/MPC roster is claimed. R1–R8 and R9 status are unchanged; independent academic approvals remain ZERO.


# Authoritative sources, evidence register and academic-audit status

**Research cutoff:** 23 October 2026. References below are sources for specific legal/institutional claims, not an assertion that every page was independently peer-reviewed. Where an official webpage is a dated government statement, it is treated as evidence of the government's reported programme action, not independent proof of impact.

| ID | Authority and item | Claim supported / caution | Official URL |
|---|---|---|---|
| S1 | TGPSC, Group I Notification 02/2024, Annexure II | Syllabus source search-indexed; original PDF returned HTTP 403 on direct retrieval; wording also checked against reproduction | https://websitenew.tgpsc.gov.in/preview/RElSRUNUUkVDUlVJVE1FTlROT1RJL05PVElGSUNBVElPTl9OT18wMi0yMDI0X0dyb3VwLUlfU2VydmljZXMgKDEpMjAyNDAyMjAxNDA3MzcucGRmr95v17a0y2d8i13v |
| S2 | Constitution of India (Legislative Department) | Articles 14, 15, 21, 21A, 38–47, 243A, 243G, 243W; consult consolidated current text | https://legislative.gov.in/constitution-of-india/ |
| S3 | India Code, VB-G RAM G Act, 2025 (Act 36 of 2025) | 125-day household guarantee, new statute | https://www.indiacode.nic.in/indiacode/handle/123456789/22478?view_type=browse |
| S4 | Press Information Bureau, Ministry of Rural Development, 11 May 2026 | 1 July 2026 repeal of MGNREGA; transition, job cards and wage rules; ministry account, not independent impact study | https://www.pib.gov.in/PressReleasePage.aspx?PRID=2259707&lang=2&reg=48 |
| S5 | Telangana Panchayat Raj and Rural Development department | SERP, Stree Nidhi and state rural institutions | https://www.telangana.gov.in/departments/panchayat-raj-and-rural-development/ |
| S6 | Khammam District, DRDA/SERP | SHG → VO → Mandal Samakhya → Zilla Samakhya architecture | https://khammam.telangana.gov.in/drda-serp/ |
| S7 | Yadadri Bhuvanagiri District, Mission Bhagiratha | Intended tap water and LPCD norms; design intent not functionality evidence | https://yadadri.telangana.gov.in/scheme/mission-bhagiratha/ |
| S8 | Telangana MEPMA official portal | Mission and institutional establishment of urban poverty agency | https://efms.serp.telangana.gov.in/MEPMATG/View/Home/Home.aspx |
| S9 | Suryapet District, Indiramma Indlu housing administration | ₹5 lakh assistance, selection/verification process and district implementation | https://suryapet.telangana.gov.in/housing/ |
| S10 | Telangana Housing Board | Separate urban housing authority and scheme information | https://tghb.telangana.gov.in/ |
| S11 | Suryapet District Civil Supplies Office | Telangana FSC distribution, 6 kg examples; date- and category-specific | https://suryapet.telangana.gov.in/district-civil-supplies-office/ |
| S12 | Suryapet District, Rajiv Aarogyasri | State description of ₹10 lakh family annual scheme ceiling and empanelled treatment | https://suryapet.telangana.gov.in/arogya-sri/ |
| S13 | Swachh Bharat Mission (Grameen), Department of Drinking Water & Sanitation | Phase II ODF Plus and waste-management objectives | https://www.swachhbharatmission.ddws.gov.in/about_sbm |
| S14 | Jal Jeevan Mission, Ministry of Jal Shakti | Functional taps, water quality, sustainability, community planning | https://jaljeevanmission.gov.in/node/1 |
| S15 | Rural Development Ministry / PMAY-G framework | Rural housing implementation, distinguish from PMAY-U | https://pmayg.nic.in/ |
| S16 | Ministry of Housing and Urban Affairs, PMAY-U 2.0 guidelines | Current urban housing programme and eligibility architecture | https://pmay-urban.gov.in/index.php/pmay-u-2.0-guidelines |
| S17 | Telangana State Portal, Mahila Shakti SHG buses, 2026 | Government-reported SHG asset-ownership initiative; assess contracts and net returns independently | https://www.telangana.gov.in/news/press-releases/2026/06/honble-cm-sri-a-revanth-reddy-participated-in-mahila-varotsavalu-2026-flags-off-shg-women-owned-buses-at-parade-grounds-secunderabad/ |
| S18 | National Health Mission / National Health Policy 2017 vision | Equitable affordable quality health services; NHM framework | https://nhm.gov.in/index.php |
| S19 | India Code, National Food Security Act, 2013 | Sections 3–8 and entitlement categories | https://www.indiacode.nic.in/bitstream/123456789/2113/1/201320.pdf |
| S20 | Department of Food and Public Distribution, NFSA implementation and FAQ | 75/50 national coverage norms; 5 kg PHH vs 35 kg AAY; free grain since Jan 2023 | https://dfpd.gov.in/implementation-of-nfsa/en |
| S21 | Ministry of Education, PM POSHAN | School meal coverage; historical scheme period stated by portal, check continuation | https://pmposhan.education.gov.in/aboutus.html |
| S22 | Telangana SMART-PDS portal | Distribution transactions and portability tools; dashboard figures require date stamps | https://smartpds.telangana.gov.in/ |
| S23 | India Code, RTE Act, 2009 | Article 21A implementation; 6–14 years; duties and covered-school categories | https://www.indiacode.nic.in/handle/123456789/12911?sam_handle=&view_type=browse |
| S24 | Ministry of Education, Samagra Shiksha | Integrated school-education scheme, equity and learning | https://samagra.education.gov.in/ |
| S25 | Telangana State Portal, food-security-card distribution, 14 July 2025 | Dated state administrative announcement, not independent coverage proof | https://www.telangana.gov.in/news/news-and-press-releases/2025/07/honble-cm-revanth-reddy-participated-in-the-launch-of-food-security-cards-new-ration-cards-distribution-at-thirumalagiri/ |
| S26 | Legislative Department, *Constitution of India* (as on 1 May 2026), Part IX, Articles 243A–243H | Q26–Q30 constitutional provisions; specifically State-law authority, twenty-lakh State population exception, direct elections, one-third women's minimum, and enabling fiscal law. Corrects earlier misattribution to S25 (Telangana ration-card announcement). | https://www.legislative.gov.in/static/uploads/2025/07/88cca69e868e50b217f855be2fb8bdba.pdf |
| S27 | Ministry of Rural Development, *Annual Master Circular 2024–25*, chapter 10, social audit | Historical MGNREGA social-audit method: Gram Sabha, records and independent Social Audit Units. Historical source; NOT certification of post-2026 transition rules. | https://www.dord.gov.in/static/uploads/2024/11/ac56e7f159e31f06e12beb799f206786.pdf |
| S28 | Telangana Panchayat Raj and Rural Development Department; Peddapalli DRDA | Stree Nidhi is an SHG-linked credit cooperative federation, not a court, municipality or legislative audit committee. | https://peddapalli.telangana.gov.in/district-rural-development-agency/ |

## Source-quality controls and unresolved items

1. **Official syllabus:** Original TGPSC PDF was indexed by search but returned HTTP 403 on direct retrieval; exact wording was corroborated by a public reproduction. A direct-PDF recheck is still needed before academic approval.
2. **2026 legal update:** India Code identifies Act 36 of 2025; the Ministry's 11 May 2026 notice gives 1 July 2026 commencement/repeal. Do not treat historical MGNREGA dashboard labels as proof the 2005 statute remains current.
3. **State-specific operational rules:** Do not assume Telangana has issued a particular new state employment scheme, wage rate or complaint regulation without the relevant current government order.
4. **Telangana schemes:** Housing and health amounts reflect dated official district pages; eligibility, coverage and packages can change. Government-reported totals are not causal evaluation.
5. **Legal nuance:** Health under Article 21 is an interpreted constitutional right, not unlimited free treatment; Article 21A covers ages 6–14; NFSA entitlement denominators are different for PHH and AAY.
6. **Practice questions:** All MCQs and mains prompts are newly written original practice questions; no official past question is asserted or simulated as verified.
7. **Academic approval:** Structural checks and source cross-checking are not a full subject-expert legal/factual audit. This chapter remains **NOT APPROVED**.

## 27 October 2026 — bounded primary-source correspondence, not R4/R5 approval

Ten existing practice MCQs (Q2, Q3, Q4, Q7, Q8, Q11, Q16, Q18, Q20 and Q24) were rewritten to improve key distribution, remove obviously impossible alternatives and sharpen legal or administrative distinctions. The author checked their principal propositions against the following accessible official materials. This does **not** constitute independent verification of every distractor, and the other fifteen MCQs remain unaudited.

- Constitution (73rd Amendment), Article 243G and Eleventh Schedule: https://www.legislative.gov.in/static/uploads/2025/07/d6e04624ef8b6b869af003909507cfe6.pdf and https://www.legislative.gov.in/static/uploads/2025/08/7af1daa22d65f9d04c00ae9b9aa5a799.pdf (Q2).
- Telangana Khammam DRDA/SERP federation profile: https://khammam.telangana.gov.in/drda-serp/ ; Telangana MEPMA urban mission: https://kamareddy.telangana.gov.in/mepma/ (Q3–Q4).
- India Code Act 36 of 2025: https://www.indiacode.nic.in/indiacode/handle/123456789/22478?view_type=browse ; Ministry of Rural Development/PIB release dated 11 May 2026: https://www.dord.gov.in/static/uploads/2026/05/6c0a4feea975932109261916ea1fc699.pdf (Q7–Q8).
- Department of Food and Public Distribution, NFSA implementation and FAQs: https://dfpd.gov.in/implementation-of-nfsa/en and https://dfpd.gov.in/faqs/en (Q11, Q24; the exact authentication-failure fallback is not independently certified).
- Ministry of Education, RTE guidance: https://www.education.gov.in/sites/upload_files/mhrd/files/document-reports/AssmntCCE.pdf (Q16).
- Constitutional framework and existing chapter source register for Article 21 and public-health policy (Q18); conceptual programme-output/outcome distinction (Q20).

The revised answer distribution is A4/B9/C6/D6. A balanced distribution is not evidence of correctness. No official PYQs are claimed. All six mains bodies satisfy the numerical 200–250-word target, but factual claim-by-claim review is still pending. The direct TGPSC syllabus PDF remains inaccessible and R1 is not PASS.

## 31 October 2026 — Cycle119 bounded constitutional check, not independent R5 approval

**S26 — directly inspected primary text:** Legislative Department, *Constitution of India*, Articles 243A, 243B(2), 243C(2), 243D(3), 243G and 243H: https://www.legislative.gov.in/static/uploads/2025/07/88cca69e868e50b217f855be2fb8bdba.pdf . Historical constitutional design also compared with the official 73rd Amendment Act: https://www.legislative.gov.in/static/uploads/2025/07/d6e04624ef8b6b869af003909507cfe6.pdf .

New original practice Q26–Q30: **five keys and 15 distractors checked author-side** against the named provisions; every new distractor has an explicit rationale. These are not official PYQs, not independent question certification, and do not authenticate Q1–Q25. New detailed concept 15 distinguishes deliberation, representation, functional devolution and fiscal authority. Full 30-key/90-distractor independent audit, six mains claim checks, current Telangana operational rules, official TGPSC syllabus direct PDF, browser accessibility and named academic expert remain pending. No academic approval.

## 3 November 2026 — Cycle193 source-ID repair and bounded MCQ audit

**Defect fixed:** Original Q26–Q30 cited `[S25]` even though the numbered S25 register entry is a Telangana food-security-card announcement. The Constitution had been discussed in a later unnumbered note also called S25. This is a source-identity collision, not evidence that the questions' constitutional keys were wrong. The five MCQs now cite distinct **S26**, with the exact Legislative Department consolidated text and Articles 243A–243H. The pre-existing S25 ration-card entry remains unchanged.

**Two additional original MCQs:** Q6 was rewritten to distinguish documentary accounting from public verification under the *historical* 2024 Ministry social-audit circular (S27). Q10 was rewritten to test Stree Nidhi's SHG-linked cooperative-credit function against Telangana department and district descriptions (S28). For these two questions, **two keys and six distractors** were checked author-side. The check does not establish any post-2026 social-audit legal transition rule, nor does it authenticate official PYQs.

**Remaining limitations:** Direct Commission-hosted 2024 syllabus authentication, complete 30-question independent key/distractor audit, six mains claim checks, browser/screen-reader QA and named expert review remain pending. R1 remains BLOCKED; no R1–R8 gate or independent academic approval is promoted.

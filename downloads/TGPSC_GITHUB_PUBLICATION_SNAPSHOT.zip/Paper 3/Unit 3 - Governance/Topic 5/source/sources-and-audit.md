# Primary-source register, current affairs and academic audit

**Research cut-off:** 23 October 2026. The entries below are source identifiers used in the chapter, not claims of academic peer review. Official pages may change; recheck before the examination. No source page numbers are included in the student notes.

| ID | Primary authority and document | What it supports | Link |
|---|---|---|---|
| S01 | Government of India, Second ARC, Fourth Report *Ethics in Governance*, January 2007 | Institutional ethics, integrity reforms | https://www.darpg.gov.in/sites/default/files/ethics4.pdf |
| S02 | DoPT, Central Civil Services (Conduct) Rules, 1964, updated official page | Neutrality, conduct and service obligations | https://dopt.gov.in/acts/central-civil-services-conduct-rules-1964-updated-0 |
| S03 | DARPG, Guidelines for Implementing Sevottam, September 2011 | Citizen Charters and grievance standards | https://www.darpg.gov.in/sites/default/files/Sevottam_Guidelines_Sept_2011_0.pdf |
| S04 | India Code, Right to Information Act, 2005, consolidated official PDF | RTI structure, sections and exceptions | https://www.indiacode.nic.in/bitstream/123456789/19840/1/right_yo_information_act.pdf |
| S05 | DoPT, RTI Online central filing portal | Central/state portal distinction | https://rtionline.gov.in/ |
| S06 | Telangana Government, Right to Information | State RTI institutional information | https://www.telangana.gov.in/RTI/ |
| S07 | Telangana Government, Information Commission roster | Current listed state commissioners; roster can change | https://www.telangana.gov.in/rti/information-commission/ |
| S08 | India Code, Prevention of Corruption Act, 1988, amended statute | Sections 7, 8, 9, 13, 17A and 19 | https://www.indiacode.nic.in/handle/123456789/12894 |
| S09 | India Code, Central Vigilance Commission Act, 2003 | Statutory foundation of CVC | https://www.indiacode.nic.in/handle/123456789/1362/simple-search?filter_field_2=actyear&filter_type_2=equals&filter_value_2=2003 |
| S10 | India Code, Delhi Special Police Establishment Act, 1946 | CBI police-power foundation and state consent | https://www.indiacode.nic.in/bitstream/123456789/15363/1/the_delhi_special_police_establishment_act%2C_1946.pdf |
| S11 | India Code, Lokpal and Lokayuktas Act, 2013 | National Lokpal jurisdiction | https://www.indiacode.nic.in/handle/123456789/2122 |
| S12 | Telangana Lokayukta, Telangana Lokayukta Act, 1983 | State Lokayukta legal basis | https://lokayukta.telangana.gov.in/files/Telangana-Lokayukta-Act.pdf |
| S13 | Telangana Lokayukta, RTI disclosure page | Section 4(1)(b) institutional disclosures | https://lokayukta.telangana.gov.in/rti.html |
| S14 | Telangana Vigilance Commission, official institutional history | March 2015 establishment and advisory mandate | https://tvc.telangana.gov.in/ |
| S15 | Department of Consumer Affairs, Consumer Protection Act, 2019 and rules | Consumer commissions, CCPA and regulations | https://consumeraffairs.nic.in/acts-and-rules/consumer-protection/consumer-protection |
| S16 | Department of Consumer Affairs, Annual Report 2023–24 | e-Daakhil mechanism | https://consumeraffairs.nic.in/sites/default/files/file-uploads/annualreports/1729492569_AR_2023_2024.pdf |
| S17 | Government of India, Digital Personal Data Protection Act, 2023 (official MeitY text) | Section 44(3) amending RTI Section 8(1)(j) | https://www.meity.gov.in/static/uploads/2024/06/2bf1f0e9f04e6fb4f8fef35e82c42aa5.pdf |
| S18 | Gazette of India, G.S.R. 843(E), 13 November 2025 | Commencement of DPDP Section 44(3) | https://egazette.gov.in/WriteReadData/2025/267647.pdf |
| S19 | DARPG, Second ARC Tenth Report *Refurbishing of Personnel Administration* | Personnel and performance reforms | https://darpg.gov.in/sites/default/files/personnel_administration10_0.pdf |
| S20 | DARPG, Government decisions on Second ARC reports | Citizen-centric and state/district administration reform trail | https://darpg.gov.in/government-decisions-on-2nd-arc?page=1 |
| S21 | DARPG, Sevottam and grievance-redress workshop listings, 2025 | Continuing public-service standards activity | https://darpg.gov.in/whats-new |
| S22 | Government of Telangana, Institute of Rural Development RTI guidance | Practical Telangana RTI request route | https://tgird.telangana.gov.in/rtiact.html |

| S24 | India Code, Lokpal and Lokayuktas Act, 2013, Section 3 | Union Lokpal's constituting statutory provision; not the Telangana Lokayukta | https://www.indiacode.nic.in/bitstream/123456789/2122/1/201401.pdf |
| S25 | Telangana Vigilance Commission, Introduction and Jurisdiction & Functions | 12–13 March 2015 establishment, advisory recommendations, ability to refer investigation to ACB | https://www.tvc.telangana.gov.in/jurisdiction_function.html |
| S26 | India Code, Prevention of Corruption Act, 1988 (amended), Section 7 | Undue advantage for performing public duty, even if underlying decision would be proper | https://www.indiacode.nic.in/bitstream/123456789/12894/1/prevention_of_corruption_act_1988_49_of_1988.pdf |
| S27 | Department of Consumer Affairs, S.O. 2422(E), 23 July 2020; Consumer Protection Act, 2019, Section 10 | CCPA legal basis and establishment effective 24 July 2020 | https://consumeraffairs.nic.in/sites/default/files/Estt%20of%20CCPA.pdf |

## Dated developments to integrate with static syllabus

**13 November 2025 — privacy and transparency:** Gazette G.S.R. 843(E) brought Section 44(3) of the DPDP Act into force, amending the RTI Act's personal-information exemption. It did not commence the entire DPDP Act at once. Primary documents: S17–S18. The impact on public-interest disclosure remains a legal and policy debate; avoid claiming that all personal-information requests are necessarily rejected.

**2025–2026 — Telangana Information Commission:** The official Telangana government page lists the current Chief Information Commissioner and Information Commissioners (S07). The roster confirms institutional appointments but cannot alone establish backlog clearance or decision quality. For any numeric performance claim, use a dated annual report rather than extrapolating from names.

**March 2015 / September 2024 — Telangana Vigilance Commission:** The Commission's official site records establishment in March 2015 and appointment of its second commissioner in September 2024 (S14). Its role is advisory; the institution is not the CVC or a constitutional court.

**2025 — DARPG Sevottam activity:** The department listed a national workshop on Sevottam and effective public grievance redress on 25 April 2025 (S21). This documents reform activity, not proven nationwide service outcomes.

## Provenance and quality flags

1. The official TGPSC Notification 02/2024 full PDF could not be directly retrieved in this production run; exact syllabus item was checked against a published reproduction. **Primary-syllabus retrieval remains open.**
2. No official TGPSC question paper with a verified question number was obtained. All 30 MCQs and six mains prompts are original practice; **zero official PYQs verified**.
3. The 2025 DPDP/RTI amendment is supported by the primary Gazette and MeitY text. The detailed effect of its interpretation requires current case-law review; no blanket claim about the legality of all disclosures is made.
4. State service rules, commission membership and consumer pecuniary jurisdiction may change; the chapter avoids unsourced universal thresholds and treats the official current rules as controlling.
5. Statutory text, institutional webpages and administrative guidance have been internally cross-checked for role and date. **No independent academic review or line-by-line legal peer audit has occurred.**
6. PDF/HTML/ZIP validation is a production check, not proof that every factual assertion is error-free.

## 27 October 2026 — Cycle 34 bounded practice-MCQ editorial and source audit

Fifteen EXISTING original practice questions (3, 5, 6, 7, 9, 10, 11, 12, 17, 18, 19, 21, 23, 24, 25) were rewritten in place with more discriminating alternatives and option-specific explanations. All 25 remain newly authored practice questions; none is claimed as a verified official PYQ. Original 31-page PDF is retained. The revised bank's A/B/C/D answer distribution is 10/5/5/5, but balance is not evidence of factual correctness.

Dated author-side primary-source correspondences (not independent academic certification):

- [C34-01] DARPG, *Designing and Implementing Sevottam* (September 2011), service standards, grievance redress, service capability (Q5–Q6): https://www.darpg.gov.in/sites/default/files/Sevottam_Guidelines_Sept_2011.pdf
- [C34-02] India Code, *Sexual Harassment of Women at Workplace Act, 2013*, sections 4 and 6, Internal/Local Committees (Q7): https://upload.indiacode.nic.in/showfile?actid=AC_CEN_13_14_00009_201314_1517807327213&filename=a2013-14.pdf&type=actfile
- [C34-03] India Code, *Prevention of Corruption Act, 1988* (as amended), section 7 (Q9): https://www.indiacode.nic.in/bitstream/123456789/12894/1/prevention_of_corruption_act_1988_49_of_1988.pdf
- [C34-04] India Code, *Central Vigilance Commission Act, 2003* (Q10): https://www.indiacode.nic.in/bitstream/123456789/2067/1/A2003-45.pdf
- [C34-05] India Code, *Delhi Special Police Establishment Act, 1946*, sections 2–6 (Q11–Q12): https://www.indiacode.nic.in/bitstream/123456789/2258/1/A1946-25.pdf
- [C34-06] DoPT official RTI legislation index and amended RTI text, sections 2, 4, 6, 7, 10, 19 (Q17–Q19, Q21, Q23): https://rti.dopt.gov.in/
- [C34-07] DARPG, Second ARC Fourth Report, *Ethics in Governance* (January 2007), Q3 and Q24: https://darpg.gov.in/sites/default/files/ethics4.pdf
- [C34-08] DARPG, Second ARC Twelfth Report, *Citizen Centric Administration*, Sevottam service quality and grievance outcomes (Q25): https://darpg.gov.in/sites/default/files/ccadmin12.pdf

Verification boundary: item-level author-side comparisons to the listed government texts for the relevant legal/institutional propositions; no independent examiner, no complete legal audit of all 25 questions and 100 alternatives, no independent mains claim audit, and no direct official Commission syllabus PDF retrieval. Q3/Q25 remain evaluative scenarios, not statutory holdings. R1/R4/R5/R6 remain unpassed; R9 not started.

## Cycle 121 — 31 October 2026: RTI remedies, primary-source register and bounded question audit

**[S23] India Code, Right to Information Act, 2005, consolidated as on 18 November 2025:** https://upload.indiacode.nic.in/showfile?actid=AC_CEN_26_36_00004_200522_1517807322955&filename=a2005-22.pdf&type=actfile . Sections 7(2), 7(6), 7(8), 18, 19(1), 19(3), 19(5), 19(6), 19(8), 20(1) and 20(2) were directly inspected. The consolidated text records the post-13-November-2025 amendment of Section 8(1)(j); Gazette [S18] independently documents its commencement.

| Audit ID | Question | Correct key and primary section | Three distractors individually checked |
|---|---|---|---|
| C121-01 | Q26 | B; Section 19(8)(a)(i) | A CVC is not RTI disclosure forum; C Section 20 is not direct civil-court relief; D Section 24 is an exclusion mechanism |
| C121-02 | Q27 | C; Section 7(6) | A no surcharge; B no automatic dismissal; D delay creates no exemption |
| C121-03 | Q28 | D; Section 19(5) | A applicant not burden-holder; B police not specified; C auditor not specified |
| C121-04 | Q29 | B; Section 20(1) | A wrong rate/cap; C wrong automatic flat penalty; D wrong monthly rate and beneficiary |
| C121-05 | Q30 | C; Section 19(6) | A 48-hour rule is for life-or-liberty requests; B statutory period exists; D 90 days concerns second-appeal filing |

**Verification boundary:** The five new keys and 15 new distractors were author-side correlated with the named primary statutory provisions; these are not independent examiner approvals. All 30 questions are original practice; verified official PYQs remain zero. The previous 25 keys/75 distractors and six mains answers still require independent claim-level audit. Direct Commission-hosted syllabus authentication, full browser accessibility, diagram review and named expert approval remain pending. R1–R8 are incomplete; R9 NOT_STARTED.

## Cycle 195 — 3 November 2026: Four institutional-remedy MCQs revised in place

Original practice Q13–Q16 were rewritten to distinguish the Union Lokpal, Telangana Vigilance Commission, state anti-corruption investigation and CCPA. The four correct answers and twelve distractors received **bounded author-side primary-document comparisons**; this is neither independent legal review nor official PYQ authentication.

| Audit | Question | Key | Primary support | Distractor check |
|---|---|---|---|---|
| C195-01 | Q13 | B | S24, Lokpal Act s.3 | A CVC separate; C Telangana state ombudsman; D PC Act offences, not Lokpal constitution |
| C195-02 | Q14 | C | S25, TVC establishment and jurisdiction | A Union/state confusion; B advisory ≠ conviction; D RTI forum separate |
| C195-03 | Q15 | A | S25 TVC ACB referral; S26 PC Act s.7 | B consumer body; C RTI appeal; D audit ≠ criminal verdict |
| C195-04 | Q16 | D | S27, CCPA notification; Consumer Act 2019 s.10 | A RTI; B CVC; C wrong Act, authority, date |

**Boundary:** The institutional sources establish their described powers and dates, not that any particular complaint was registered, any prosecution succeeded or any 2026 administrative roster remains unchanged. All 30 practice questions and six mains answers are retained. Remaining questions, mains, official Commission PDF, diagram and accessibility review are not independently certified. R1–R8 incomplete; R9 NOT_STARTED; independent approvals ZERO.

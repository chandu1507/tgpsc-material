# Primary-source register, dated current affairs and audit

**Status:** production draft only; **academic approval: zero**. The source register documents authoritative material consulted. It is not an independent subject-expert review. Student-facing notes do not use page-number citations.

| ID | Authority / item | Source and relevance |
|---|---|---|
| S01 | United Nations Statistics Division, System of National Accounts | https://unstats.un.org/unsd/nationalaccount/sna.asp — production boundary, accounts and residence concepts |
| S02 | MoSPI, new GDP series, 27 February 2026 | https://mospi.gov.in/uploads/latestReleases/latest_release_1772189865181_f040336d-bc57-4aed-b80f-586d9ccb279e_Press_Note_on_New_Series_of_GDP_Estimates_with_Base_Year_2022-23_27022026.pdf — 2022–23 base-year introduction; secondary indexing accessible, direct retrieval intermittently denied |
| S03 | MoSPI, National Accounts FAQ | https://mospi.gov.in/faq — methodology, GSDP guidance, double deflation, discrepancy and later price-series revisions |
| S04 | MoSPI, National Accounts Statistics dashboard | https://esankhyiki.mospi.gov.in/ — contemporary GDP releases and statistical indicators |
| S05 | MoSPI, 5 June 2026 provisional FY 2025–26 GDP estimates | https://www.mospi.gov.in/uploads/latestreleasesfiles/1780656381622-Press%20Note%20on%20GDP%20Estimates%20for%20Q4%202025-26%20and%20PE%20FY%202025-26_F.pdf — 7.7% real growth, ₹346.36 lakh crore nominal GDP, GVA and broad-sector composition |
| S06 | Government of Telangana, Socio-Economic Outlook 2026 | https://www.telangana.gov.in/wp-content/uploads/2026/08/Socio-Economic-Outlook-2026.pdf — GSDP, sectoral structure, PCI; official file identified but too large for current direct text retrieval |
| S07 | Invest Telangana, official state investment portal | https://invest.telangana.gov.in/why-telangana/ — state-reported 2025–26 GSDP and per-capita figures |
| S08 | MoSPI, Periodic Labour Force Survey | https://mospi.gov.in/ — employment comparisons require PLFS rather than inference from GVA shares |
| S09 | UN System of Environmental-Economic Accounting | https://seea.un.org/ — environmental accounts as complements to GDP |
| S10 | Notification 02/2024 Annexure-II syllabus reproduction | https://keshav.ugenglish.in/2024/02/tspsc-group-1-notification-022024.html — exact Paper IV Unit I item 1 wording, primary official PDF not fully retrieved |
| S11 | TGPSC official scheme/syllabus portal | https://websitenew.tspsc.gov.in/ and https://uat3.cgg.gov.in/website/SyllabusCMS — original commission access route |
| S12 | MoSPI, National Accounts Statistics publications | https://mospi.gov.in/publication/national-accounts-statistics-2025 — source and method descriptions |
| S13 | MoSPI, Q1 FY 2026–27 GDP dashboard | https://www.mospi.gov.in/themes/product/6-gross-domestic-product — Q1 real GDP growth reported 7.8%; subject to release revisions |

## Dated current-affairs capsules (primary sources)

**27 February 2026 — GDP series rebased.** MoSPI introduced the 2022–23-base series in place of 2011–12. Significance: new sector weights and data can change historical estimates, so old-series growth figures should not be spliced with new-series levels. [S02–S03]

**5 June 2026 — FY 2025–26 provisional national accounts.** MoSPI reported 7.7% real GDP growth and 8.9% nominal growth, with ₹323.12 lakh crore real GDP and ₹346.36 lakh crore nominal GDP. The February second-advance real growth estimate had been 7.6%; this is a revision, not two simultaneous truths. [S05]

**31 August 2026 release cycle — price and industrial inputs updated.** MoSPI's FAQ states that newer PPI and IIP series were incorporated into GDP estimates, retaining 2022–23 as base year. The Q1 FY 2026–27 dashboard subsequently showed 7.8% real GDP growth. A later-vintage historical series may not exactly match June provisional numbers. [S03, S13]

**2026 Telangana outlook — services-led GSDP.** The state government's 2026 report and investment portal report a current-price GSDP around ₹17.82 lakh crore and a per-capita income around ₹4.19 lakh. Distinguish government estimate, currency conversion, price basis and state–national comparability. [S06–S07]

## Provenance and unresolved checks

- **Official question papers:** No original TGPSC paper plus question number was authenticated for this exact topic. All 25 MCQs and six mains questions are explicitly **original practice**, not PYQs. No official answer key is claimed.
- **Syllabus:** Exact phrase checked against a published reproduction of Annexure-II; official Notification 02/2024 PDF not fully retrievable in this session. Direct primary-text audit remains open.
- **National data:** 5 June MoSPI provisional PDF was directly readable. New-series February document was identified through MoSPI indexing, with access restrictions on the full PDF. Subsequent revisions are acknowledged rather than silently merged.
- **Telangana data:** Official report PDF was identified but exceeded the browser fetch limit; the state portal and investment portal were accessible. State figures are labelled estimates; original PDF numerical table should be checked before academic approval.
- **Quality:** Arithmetic examples, formulas, counts and cited data vintages were internally checked. A specialist still needs to audit statistical nuance, syllabus completeness and answer suitability.

# Authoritative source register and audit

**Source method:** Primary RBI, Government of India, DICGC and Telangana government materials are used for institutional and dated factual claims. The syllabus line is corroborated by public reproductions; the original Notification 02/2024 PDF was not directly authenticated in this run. Source identifiers in notes refer to the register below; page numbers are intentionally omitted. Accessed 23 October 2026 unless a publication date is stated.

| ID | Source / date | URL | Used for | Audit limitation |
|---|---|---|---|---|
| S01 | RBI, monetary aggregate definitions | https://www.rbi.org.in/scripts/PublicationsView.aspx?Id=22715 | M0, M1–M4 and NM aggregates | Formulae checked; figures in worked examples invented for illustration |
| S02 | RBI, monetary and liquidity aggregates explanatory publication | https://systemhealth.rbi.org.in/Scripts/PublicationsView.aspx_id%3D9455.html | Functions and monetary-statistical boundary | Older conceptual source; definitions verified with S01 |
| S03 | RBI Bulletin, money stock measures, 17 Jan 2025 | https://www.rbi.org.in/scripts/bs_viewbulletin.aspx/searchnew/BS_ViewBulletin.aspx?Id=23140 | Reporting dates and component categories | Not used as a 2026 monetary stock |
| S04 | Reserve Bank of India official portal | https://www.rbi.org.in/ | Central banking, policy and regulation | Policy rates change; no unsupported October 2026 rate asserted |
| S05 | India Code, RBI Act 1934, Banking Regulation Act 1949, PSS Act 2007 | https://www.indiacode.nic.in/ | Enabling legislation | Statutory detail requires final legal audit |
| S06 | Department of Financial Services, Banking page | https://financialservices.gov.in/banking | 12 PSBs, bank amalgamations, EASE | Institution list as displayed on official page |
| S07 | RBI Financial Stability Reports | https://www.rbi.org.in/Scripts/FsReports.aspx | Prudential, systemic risk, stress tests | No numerical stress projection quoted |
| S08 | DICGC Guide to Deposit Insurance | https://www.dicgc.org.in/guide-to-deposit-insurance | ₹5 lakh insurance, exclusions, same bank/capacity | Deposit eligibility varies by account capacity |
| S09 | DFS review of RRBs, 2022–23 | https://financialservices.gov.in/beta/sites/default/files/2024-08/Consolidated-Review-of-RRBs-2022-23.pdf | RRB purposes, ownership and mergers | Do not infer current RRB counts from older review |
| S10 | RBI official education / monetary operations | https://www.rbi.org.in/financialeducation/ | Money and bank-deposit distinctions | Explanatory rather than current statistics |
| S11 | Government of Telangana, Kamareddy district banking | https://kamareddy.telangana.gov.in/banking/ | Lead District Manager and district committees | Branch counts may be outdated; none used |
| S12 | RBI Master Directions portal | https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx | NBFC and prudential frameworks | Exact current directions must be cross-checked |
| S13 | RBI August 2026 portal archive | https://m.rbi.org.in/Scripts/NotificationUser.aspx?Id=10001&Mode=0 | Dated policy repo example, MPC material | Not asserted as current on 23 Oct 2026 |
| S14 | DFS, Banking reforms and EASE | https://financialservices.gov.in/banking | Post-1991 reforms and PSB governance | Narasimham committee history from standard official chronology |
| S15 | DFS Banking Analytics, data through 31 March 2026 | https://www.financialservices.gov.in/banking-analytics | GNPA stock comparison and bank offices | Stock is not ratio or recovery; data vintage explicit |
| S16 | RBI Priority Sector Lending Master Direction | https://systemhealth.rbi.org.in/Scripts/BS_ViewMasDirections.aspx_id%3D11959%282%29.html | 40% ANBC broad target and exceptions | Verify later amendments for exam-day targets |
| S17 | Public reproduction of TGPSC Notification 02/2024 Annexure-II | https://prepshark.in/tgpsc/group-1/syllabus | Exact topic syllabus wording | Secondary transcription; direct commission PDF still outstanding |
| S18 | Public copy of Group I notification wording | https://keshav.ugenglish.in/2024/02/tspsc-group-1-notification-022024.html | Cross-check syllabus line | Secondary reproduction |

## Explicit verification and provenance gaps

1. The original official Notification 02/2024 PDF was not downloaded for a line-by-line comparison in this run; this chapter's syllabus line is corroborated by two public reproductions, not independently certified against the original scan.
2. No question is described as an official PYQ because no source examination paper plus question number was validated. All 25 MCQs and six mains prompts are newly written practice material.
3. Monetary policy rates are time-sensitive; only a clearly dated August 2026 snapshot is mentioned. The latest October MPC decision is not independently verified here.
4. The district government page documents coordination functions but may contain older bank counts; those counts were intentionally excluded.
5. Banking regulation and PSB counts can change. Before academic approval, a subject specialist should review the current RBI directions, law amendments, and any subsequent institution mergers.
6. Structural validation, source triangulation and PDF visual inspection are **not independent academic approval**.

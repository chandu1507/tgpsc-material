# Authoritative Sources, Dated Updates and Internal Audit

**Audit cut-off: 24 October 2026.** The chapter cites named statutes, institutions and official portals. Source IDs appear at the ends of detailed sections for traceability. Sources are not page-number references. URLs are included to permit rechecking; access to a source does not imply independent legal or academic approval.

| ID | Authority and document | Primary link | Claim checked and qualification |
|---|---|---|---|
| S01 | Constitution of India, Legislative Department | https://www.indiacode.nic.in/bitstream/123456789/16124/1/the_constitution_of_india.pdf | Articles 31A, 31B, 39 and 300A; constitutional interpretation requires current case law. |
| S02 | Legislative Department, Ninth Schedule | https://www.legislative.gov.in/static/uploads/2025/08/cb1b190ea633a1746368ed1fac35fb30.pdf | Hyderabad Jagir Regulations among original Ninth Schedule entries. |
| S03 | Hyderabad (Abolition of Jagirs) Regulation, 1358 Fasli, recognised in Ninth Schedule | https://www.legislative.gov.in/static/uploads/2025/08/cb1b190ea633a1746368ed1fac35fb30.pdf | Historical legal title and protection; full regulation text not separately authenticated in this run. |
| S04 | India Code, Telangana Jagirdars Debt Settlement Act, 1952 | https://www.indiacode.nic.in/bitstream/123456789/8663/1/act_12_of_1952.pdf | Definitions and references to the 1358 Fasli Jagir Regulation. |
| S05 | India Code, Telangana Abolition of Inams Act, 1955 | https://www.indiacode.nic.in/bitstream/123456789/8597/1/act_8_of_1955.pdf | Sections on vesting and occupant registration, including tenant categories. |
| S06 | India Code, Telangana Tenancy and Agricultural Lands Act, 1950 | https://www.indiacode.nic.in/bitstream/123456789/8575/1/act_21_of_1950.pdf | Protected tenancy and statutory ownership mechanisms; no automatic universal ownership. |
| S07 | Telangana Revenue Department, Bhu Bharati documents | https://bhubharati.telangana.gov.in/BhubharatiDocuments | Act 1 of 2025, G.O.Ms.No.36 and G.O.Ms.No.39 listed as official documents. |
| S08 | India Code, Telangana Tenancy Act 1950 | https://www.indiacode.nic.in/bitstream/123456789/8575/1/act_21_of_1950.pdf | Historical tenant rights; case-specific eligibility is essential. |
| S09 | India Code, Telangana Bhoodan and Gramdan Act, 1965 | https://www.indiacode.nic.in/bitstream/123456789/8712/1/act_13_of_1965.pdf | Donation and institutional framework. |
| S10 | India Code, Telangana Bhoodan Act metadata | https://www.indiacode.nic.in/indiacode/handle/123456789/8712?view_type=browse | Statutory name, date and purpose. |
| S11 | India Code, Telangana Land Reforms (Ceiling on Agricultural Holdings) Act, 1973 | https://www.indiacode.nic.in/bitstream/123456789/8693/1/act_1_of_1973.pdf | Standard holding, declarations, tribunals, surrender and vesting. |
| S12 | Andhra Pradesh Reorganisation Act, 2014, official Telangana copy | https://eprocurement.telangana.gov.in/downloads/re-organization-act.pdf | Territorial continuity and adaptation of state laws after bifurcation. |
| S13 | India Code, Telangana Assigned Lands (Prohibition of Transfers) Act, 1977 | https://www.indiacode.nic.in/bitstream/123456789/8711/1/act_9_of_1977.pdf | Non-alienation for specified assigned lands; exceptions and procedures require bare-act check. |
| S14 | Ministry of Tribal Affairs, Bhuria Committee report appendix | https://tribal.nic.in/downloads/Statistics/OtherReport/BhuriaReportFinal.pdf | Scheduled Area land-transfer regulation 1959, extension 1963 and protection. |
| S15 | Constitution of India, Ninth Schedule entries 203–205 | https://www.indiacode.nic.in/bitstream/123456789/16124/1/the_constitution_of_india.pdf | 1959 Regulation, 1963 extension and 1970 amendment specifically named. |
| S16 | Ministry of Tribal Affairs, Forest Rights Act resources | https://tribal.nic.in/FRA.aspx | Individual/community forest rights and Gram Sabha role. |
| S17 | Ministry of Tribal Affairs, PESA resource | https://tribal.nic.in/knowledgeHub.aspx | PESA and Scheduled Area local governance, distinct from FRA and 1/70. |
| S18 | Telangana Revenue Department, Bhu Bharati Citizen page | https://www.bhubharati.telangana.gov.in/Citizen | CCLA and Revenue Department institutional roles. |
| S19 | Telangana Revenue Department, Bhu Bharati Rules, G.O.Ms.No.39, 14 April 2025 | https://bhubharati.telangana.gov.in/assets/images/userManuals/G_O_Ms_no_39_Dated_14_04_2025.pdf | Primary dated rules for records, mutation, correction, appeals. |
| S20 | India Code, Telangana land-reform and assigned-land statutes | https://www.indiacode.nic.in/bitstream/123456789/8693/1/act_1_of_1973.pdf | Legal mechanisms and implementation stages; no unsourced redistribution totals quoted. |

## Syllabus provenance

**Commission document to authenticate:** TGPSC Group-I Services Notification 02/2024, Annexure-II, issued 19 February 2024. The exact topic wording was cross-checked against published reproductions at https://prepshark.in/tgpsc/group-1/syllabus and https://keshav.ugenglish.in/2024/02/tspsc-group-1-notification-022024.html. Neither reproduction is a substitute for direct inspection of the original commission-hosted PDF; that remains an academic audit gap.

## Recent developments checked

- **4 January 2025:** Telangana Bhu Bharati (Record of Rights in Land) Act, 2025, Telangana Act 1 of 2025, listed by the official state document repository. The Act concerns record administration and does not independently prove land redistribution.
- **14 April 2025:** G.O.Ms.No.39, Telangana Bhu Bharati (Record of Rights in Land) Rules, 2025. The primary order covers record preparation, correction, mutation and appeal processes. A separate G.O.Ms.No.36 is also listed on the official portal.
- **2026:** Official Ministry of Tribal Affairs FRA resource page lists monthly progress reports through June 2026. This chapter does not invent Telangana-specific claim totals from those reports; district-level verification is pending.
- **2026:** News descriptions of map-linked Bhu Bharati registration and phased implementation are treated as reported activity, not proof of completed statewide cadastral surveys or final disposal of land disputes. The current gazette and government orders govern.

## Internal source checks and unresolved issues

**Checked internally:** Statute names, dates, distinction between 1959/1963/1970, Section 38-E's role, ceiling 'standard holding' concept, Bhoodan Act, Assigned Lands Act, 2025 Act and 14 April 2025 Rules. Claims avoid unverified acre counts and distinguish legal mechanisms from observed outcomes.

**Still pending independent academic audit:** Direct original commission syllabus PDF; complete historical Jagir Regulation and current case-law treatment; section-by-section currency of amended tenancy/ceiling/tribal regulations; district-wise official Telangana redistribution/possession data; primary Agricultural Census ownership-versus-operation comparisons; legal expert review of all 30 MCQ keys and six mains models. These gaps prevent academic approval.

**Question provenance:** Thirty MCQs and six mains questions are original practice. **Zero official PYQs are verified** because no original TGPSC question paper with question number was authenticated for this topic. Do not retrofit invented PYQ years.

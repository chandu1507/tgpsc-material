# Sources, dated updates and verification audit

**Evidence rule:** Syllabus wording was checked directly against the commission-hosted Notification 02/2024. Dated source facts are distinguished from targets, projections and conceptual illustrations. No page numbers appear in the student-facing notes.

## Dated, source-verified developments

- **19 February 2024:** Notification 02/2024 provides the official Paper IV, Unit III, Topic 3 wording. This fixes the chapter scope.
- **25 October 2014 / 14 May 2015:** Telangana Biodiversity Board records its establishment and subsequent state rules. These are institutional dates, not new 2026 developments.
- **December 2022:** The Kunming–Montreal framework was adopted, establishing four long-term goals and 23 targets for 2030. The 30% conservation/restoration numbers are targets, not certified achievements.
- **2019:** IPBES estimated that up to one million animal and plant species are threatened with extinction. The estimate is a risk assessment and should not be misquoted as an extinction tally.
- **24 October 2026 source check:** Telangana Forest Department currently describes 2 tiger reserves, 3 national parks and 7 wildlife sanctuaries. Website-reported counts may change; do not treat them as independent current field censuses.

## Primary-source register

| ID | Publisher | Date | Document / evidence | URL | Audit limitation |
|---|---|---|---|---|---|
| S01 | TGPSC | 19 February 2024 | Notification 02/2024 Annexure II official syllabus | https://websitenew.tgpsc.gov.in/preview/RElSRUNUUkVDUlVJVE1FTlROT1RJL05PVElGSUNBVElPTl9OT18wMi0yMDI0X0dyb3VwLUlfU2VydmljZXMgKDEpMjAyNDAyMjAxNDA3MzcucGRmr95v17a0y2d8i13v | Direct PDF text confirmed official topic line. |
| S02 | NCERT | Current online textbook catalogue checked 24 October 2026 | Class XII Biology, Ecology and Biodiversity chapters | https://ncert.nic.in/textbook.php?lebo1=13-13 | Conceptual framework; no numerical facts inferred from catalogue. |
| S03 | MoEFCC | Accessed 24 October 2026 | Convention on Biological Diversity overview | https://moef.gov.in/convention-on-biological-diversity-cbd | Three CBD objectives and biodiversity levels. |
| S04 | MoEFCC | Accessed 24 October 2026 | National Biodiversity Authority institutional overview | https://moef.gov.in/index.php/national-biodiversity-authority | NBA, SBBs, BMCs and local documentation. |
| S05 | Telangana Biodiversity Board | Board constitution 25 October 2014; rules 14 May 2015 | Official board history | https://tgbiodiversity.org/ | Institutional dates, not a claim about present committee count. |
| S06 | Telangana Forest Department | Accessed 24 October 2026 | Official wildlife and protected-area overview | https://forests.telangana.gov.in/Wildlife.aspx | Protected-area categories and website-reported fauna counts. |
| S07 | Telangana Forest Department | Accessed 24 October 2026 | Official forest department home | https://forests.telangana.gov.in/ | State forest institutions and reserve links. |
| S08 | Kawal Tiger Reserve | Reserve declared 2012; website accessed 24 October 2026 | Official reserve profile | https://kawaltiger.com/ | Location, forest type and habitat; inventory counts are not new censuses. |
| S09 | Telangana Tourism Department | Accessed 24 October 2026 | Official nature destinations | https://www.tourism.telangana.gov.in/experience/nature | Amrabad, Eturnagaram and Pakhal descriptions. |
| S10 | Convention on Biological Diversity | 19 December 2022 | Kunming–Montreal Global Biodiversity Framework adoption | https://www.cbd.int/article/cop15-cbd-press-release-final-19dec2022 | Four goals and 23 targets; targets not outcomes. |
| S11 | Convention on Biological Diversity | Accessed 24 October 2026 | GBF Target 2 ecosystem restoration | https://www.cbd.int/restoration | 30% degraded-ecosystem restoration ambition by 2030. |
| S12 | Convention on Biological Diversity | Accessed 24 October 2026 | GBF Target 3 conservation | https://www.cbd.int/gbf/targets/3 | Effective, equitable 30% area-conservation ambition by 2030. |
| S13 | IPBES | 6 May 2019 | Global assessment media release | https://www.ipbes.net/media-release-nature%E2%80%99s-dangerous-decline-%E2%80%98unprecedented%E2%80%99-species-extinction-rates-%E2%80%98accelerating%E2%80%99 | Estimated threatened species and main drivers; not extinctions already recorded. |
| S14 | IPBES | 22 May 2019 | Explanation of one-million threatened-species estimate | https://www.ipbes.net/ru/node/35290 | Methodology and uncertainty. |
| S15 | CBD Secretariat | Accessed 24 October 2026 | Kunming–Montreal Global Biodiversity Framework | https://www.cbd.int/gbf | Global targets and implementation mechanisms. |
| S16 | India Code | Statutory framework as amended | Biological Diversity Act, 2002 and amendment, 2023 | https://www.indiacode.nic.in/ | Use primary statute for section-level verification before quoting exact current obligations. |
| S17 | Ministry of Tribal Affairs | Statutory framework 2006 | Scheduled Tribes and Other Traditional Forest Dwellers (Recognition of Forest Rights) Act | https://tribal.nic.in/FRA.aspx | Forest rights context; no unsupported case outcome. |
| S18 | MoEFCC | Statutory framework 1972 as amended | Wild Life (Protection) Act | https://moef.gov.in/ | Protected area governance context; precise legal sections need independent check. |
| S19 | CBD Secretariat | Accessed 24 October 2026 | 2030 GBF targets and guidance | https://www.cbd.int/gbf/targets | Targets are normative commitments. |
| S20 | Telangana State Portal | Accessed 24 October 2026 | Environment and Forests department profile | https://www.telangana.gov.in/departments/environment-forests/ | Department roles including forest land and conservation. |
| S21 | Telangana Forest Management Information System | Accessed 24 October 2026 | State forest monitoring system | https://fmis.telangana.gov.in/ | Monitoring infrastructure, not a biodiversity census. |

## Independent audit still required

1. Peer review of biological terminology, local species records and any new legislation or amendments.
2. Confirm individual species protection schedules from the latest authenticated legal text before making legal claims.
3. Audit source availability and official question-paper provenance separately. No original practice question is represented as a PYQ.
4. Inspect complete PDF for visual defects and validate every HTML image/link path.
5. Academic status remains **not approved** until independent review.
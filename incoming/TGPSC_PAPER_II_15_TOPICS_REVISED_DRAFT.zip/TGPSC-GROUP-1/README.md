# TGPSC Group 1 — Portal Initialization

Open `index.html` in Chrome or Edge on your laptop. The portal works offline without an API key or web server.

Navigation: Paper → Unit → Topic → sections. Search and filters work locally. Every content section is currently marked pending.

This is an INITIALIZE-only scaffold: 75 topic directories, progress manifest, PYQ register, responsive HTML portal. **No notes or PDFs generated.** Official syllabus extraction/verification is pending.

The latest stated preferences conflict: an earlier message requests extensive notes and one combined PDF per topic; the most recent explicit approval selected balanced notes and separate PDFs. Confirm before content generation.

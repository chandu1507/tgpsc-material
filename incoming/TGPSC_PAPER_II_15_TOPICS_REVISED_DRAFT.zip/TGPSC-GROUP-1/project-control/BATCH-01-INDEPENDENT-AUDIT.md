# Batch 01 independent QA checkpoint — 22 October 2026

**Scope:** Paper II / Unit I / Topics 1–5. Read and counted text in the actual ZIP supplied at the start of this run. This is a production QA checkpoint, **not** academic approval.

## Improvements made

1. Topic 2: supplied two additional **complete original mains model answers** (Bhakti/Sufi traditions; architectural patronage), with answer-writing blueprints and qualified historical interpretation. Each prompt is explicitly non-official.
2. Topic 2: added a September 2025 Ramappa **ASI tender record** as a narrowly verified contemporary case, carefully distinguishing a tender from completed conservation.
3. Topic 2: appended the answer and source supplement to the **self-contained complete-notes.pdf**. Retained separate Markdown editable sources.
4. Added this independently recomputed file-level quality report and a structured CSV for the five topics.

## Source record

- Official examination framework: TGPSC Notification No. 02/2024 dated 19 February 2024 (Annexure II): https://websitenew.tgpsc.gov.in/preview/RElSRUNUUkVDUlVJVE1FTlROT1RJL05PVElGSUNBVElPTl9OT18wMi0yMDI0X0dyb3VwLUlfU2VydmljZXMgKDEpMjAyNDAyMjAxNDA3MzcucGRmr95v17a0y2d8i13v
- Archaeological Survey of India September 2025 tender index: https://asi.nic.in/HQ/tenders/?p=17
- UNESCO Ramappa World Heritage site: https://whc.unesco.org/en/list/1570/

**Limitation:** Commission-hosted authentic 2024 mains questions and answer keys were not obtained in this pass. Previous-year questions remain **zero authenticated**, and original questions cannot be presented as PYQs.

## Measured source coverage

| Topic | Detailed text words | Model-answer source words | PDF pages | Official PYQs verified | Fully approved |
|---|---:|---:|---:|---:|---|
| 1 | 2080 | 479 | 16 | 0 | No |
| 2 | 1987 | 848 | 16 | 0 | No |
| 3 | 1900 | 733 | 11 | 0 | No |
| 4 | 2118 | 782 | 10 | 0 | No |
| 5 | 2776 | 1067 | 14 | 0 | No |

**Audit implications:** Model answer source file counts do not always capture models embedded in `original-practice.md`; this table is a source-file diagnostic rather than an exhaustive count of all answers. Unit I is still a draft collection, not a completed textbook. Detailed source tracing, diagrams, PYQ authentication, current-affairs coverage and answer consistency remain pending. In particular, all five topics require an independent examination of official question-paper scans before any prior-year tagging. Topic 1–5 headings and syllabus mappings must be checked against the actual Annexure II clauses as the authoritative source. Source references should be page-specific before final approval.

## Next work

Finish topic-by-topic syllabus clause reconciliation, collect official PYQs, verify their exact wording and question numbers, and review every diagram, date and model-answer claim. Only then revisit approval status.
